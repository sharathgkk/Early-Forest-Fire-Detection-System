import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Flame, Chrome, ShieldCheck, Loader2 } from 'lucide-react';
import { auth, googleProvider, signInWithPopup, syncUserProfile } from '../lib/firebase';

interface LoginProps {
  onLoginSuccess: () => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      await syncUserProfile(result.user);
      onLoginSuccess();
    } catch (err: any) {
      console.error('Google login error:', err);
      const errorCode = err.code;
      if (errorCode === 'auth/popup-closed-by-user') {
        setError('Login cancelled. Please try again.');
      } else if (errorCode === 'auth/operation-not-allowed') {
        setError('Google Sign-in is not enabled. Please enable Google Sign-in in your Firebase Console.');
      } else if (errorCode === 'auth/unauthorized-domain') {
        setError(`This domain is not authorized. Please add "${window.location.hostname}" to the "Authorized domains" list in Firebase Console.`);
      } else {
        setError(`Login failed (${errorCode || 'Unknown error'}). Ensure your domain is authorized and provider is enabled in Firebase Console.`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-6 font-sans">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-600/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[100px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full relative z-10"
      >
        <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-8 shadow-2xl backdrop-blur-sm">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-orange-600/20">
              <Flame className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-black tracking-tight text-white mb-2">FireWatch <span className="text-orange-500">AI</span></h1>
            <p className="text-[#8E9299] text-center text-sm font-medium animate-pulse">Advanced Wildfire Detection & Management System</p>
          </div>

          <div className="space-y-6">
            {/* Google Login Section */}
            <button
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 bg-white text-black font-bold py-3.5 px-4 rounded-xl hover:bg-gray-100 transition-all active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none shadow-sm cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin text-orange-500" />
                  Signing in...
                </>
              ) : (
                <>
                  <Chrome className="w-5 h-5 text-red-500" />
                  Sign in with Google
                </>
              )}
            </button>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400 text-sm"
            >
              <ShieldCheck className="w-5 h-5 flex-shrink-0 text-red-500" />
              <p className="flex-1">{error}</p>
            </motion.div>
          )}

          <div className="mt-8 pt-8 border-t border-[#141414]">
            <div className="flex items-center justify-center gap-2 text-[10px] text-[#444] font-bold uppercase tracking-widest">
              <ShieldCheck size={14} />
              Secured by Firebase Authentication
            </div>
          </div>
        </div>

        <p className="mt-8 text-center text-[#444] text-[10px] uppercase tracking-widest font-bold">
          © 2026 FireWatch AI Systems · Enterprise Grade Security
        </p>
      </motion.div>
    </div>
  );
}
