import React, { useState } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { Video, Radio, Cpu, Thermometer, Droplets, Wind, Activity, Settings, Eye, Maximize2, Zap, ShieldAlert, Navigation, Layers, Camera, Wrench, CheckCircle2, AlertTriangle, Volume2, VolumeX, Smartphone, Bell } from 'lucide-react';
import bandipurSatelliteImg from '../assets/images/bandipur_satellite_1779604905471.png';
import { SensorData, IncidentStatus, CameraNode } from '../types';
import { APIProvider, Map, AdvancedMarker, Pin, InfoWindow } from '@vis.gl/react-google-maps';

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

interface MonitoringProps {
  sensorHistory: SensorData[];
  incidentStatus: IncidentStatus;
  incidentLocation: { x: number, y: number } | null;
  onTriggerSimulation: () => void;
  cameras?: CameraNode[];
}

type CameraView = 'optical' | 'thermal' | 'lidar' | 'wide' | 'satellite';
type Resolution = '720p' | '1080p' | '4K';
type FrameRate = '30fps' | '60fps';

const bandipurCenter = { lat: 11.6664, lng: 76.6253 };

const MAP_MARKERS = [
  { id: 'S-B1', name: 'Gopalaswamy Betta Peak Station', lat: 11.7167, lng: 76.5833, battery: '88%', status: 'Active', description: 'Elevated thermal tracking on look-out point.' },
  { id: 'S-B2', name: 'Bandipur Wildlife Safari Center', lat: 11.6664, lng: 76.6253, battery: '92%', status: 'Active', description: 'Base hub main sensor and smoke receiver.' },
  { id: 'S-B3', name: 'Mel Kamanahalli Ranger Post', lat: 11.6888, lng: 76.6345, battery: '74%', status: 'Maintenance', description: 'Optical camera lens check required.' },
  { id: 'S-B4', name: 'Moolehole Border Checkpost', lat: 11.6025, lng: 76.4520, battery: '90%', status: 'Active', description: 'CO2 level scanning and wind trajectory.' }
];

export default function Monitoring({ sensorHistory, incidentStatus, incidentLocation, onTriggerSimulation, cameras = [] }: MonitoringProps) {
  const [feedSource, setFeedSource] = useState<'drone' | 'camera'>('camera');
  const [selectedCameraId, setSelectedCameraId] = useState<string>('CAM-1');
  const [cameraView, setCameraView] = useState<CameraView>('optical');
  const [resolution, setResolution] = useState<Resolution>('1080p');
  const [frameRate, setFrameRate] = useState<FrameRate>('30fps');
  const [showSettings, setShowSettings] = useState(false);
  const [selectedMapMarker, setSelectedMapMarker] = useState<typeof MAP_MARKERS[0] | null>(null);
  
  const [isRequestingTicket, setIsRequestingTicket] = useState(false);
  const [loggedTickets, setLoggedTickets] = useState<Record<string, boolean>>({});

  // Webcam access state and handler hooks
  const [useWebcam, setUseWebcam] = useState(true);
  const [hasWebcamStream, setHasWebcamStream] = useState(false);
  const webcamStreamRef = React.useRef<MediaStream | null>(null);
  const videoRef = React.useRef<HTMLVideoElement | null>(null);

  // AI Fire Computer Vision Detector and Alerting States
  const [fireProbability, setFireProbability] = useState<number>(0);
  const [isFireTriggered, setIsFireTriggered] = useState<boolean>(false);
  const [fireBbox, setFireBbox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [manualOverrideTrigger, setManualOverrideTrigger] = useState<boolean>(false);
  const [buzzerMuted, setBuzzerMuted] = useState<boolean>(false);
  const [activeToasts, setActiveToasts] = useState<{ id: string; message: string; sub: string; timestamp: string }[]>([]);
  const [showMobileNotify, setShowMobileNotify] = useState<boolean>(false);
  const [mobileNotifyMsg, setMobileNotifyMsg] = useState<string>('');
  const [twilioConfig, setTwilioConfig] = useState<{
    twilioConfigured: boolean;
    fromNumber?: string;
    defaultToNumber: string;
    verifiedNumbers: string[];
    autoDetected: boolean;
  } | null>(null);

  const [realPhoneNumber, setRealPhoneNumber] = useState<string>(() => {
    return localStorage.getItem('firewatch-real-sms-phone') || '';
  });

  const [smsStatus, setSmsStatus] = useState<{
    state: 'idle' | 'sending' | 'success' | 'error';
    message?: string;
    sid?: string;
  }>({ state: 'idle' });

  const sendRealSMSToPhone = async (phoneNumber: string, messageBody: string) => {
    setSmsStatus({ state: 'sending' });
    try {
      const response = await fetch('/api/send-sms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: phoneNumber,
          body: messageBody,
        }),
      });
      const data = await response.json();
      if (!response.ok || data.error) {
        setSmsStatus({
          state: 'error',
          message: data.details || data.error || 'Failed to dispatch SMS'
        });
      } else {
        setSmsStatus({
          state: 'success',
          sid: data.sid
        });
        // Auto-heal local state if the server determined a genuine recipient number (e.g. from registered caller IDs)
        if (data.sentTo && data.sentTo !== phoneNumber) {
          setRealPhoneNumber(data.sentTo);
          localStorage.setItem('firewatch-real-sms-phone', data.sentTo);
        }
      }
    } catch (err: any) {
      setSmsStatus({
        state: 'error',
        message: err.message || 'Network error sending SMS'
      });
    }
  };

  // Fetch default Twilio destination number from environment and Twilio console on mount
  React.useEffect(() => {
    fetch('/api/sms-config')
      .then(res => res.json())
      .then(data => {
        setTwilioConfig(data);

        // If there's an auto-detected or default caller ID, initialize the input if empty or placeholder
        const defaultNum = data.defaultToNumber || (data.verifiedNumbers && data.verifiedNumbers[0]) || "";
        if (defaultNum) {
          const stored = localStorage.getItem('firewatch-real-sms-phone');
          const isPlaceholder = !stored || stored.trim() === "" || stored.toLowerCase().includes("xxx") || stored.length < 8;
          if (isPlaceholder) {
            setRealPhoneNumber(defaultNum);
            localStorage.setItem('firewatch-real-sms-phone', defaultNum);
          }
        }
      })
      .catch(err => {
        console.warn("Could not load default SMS config: ", err);
      });
  }, []);

  // 1. Core Webcam stream activator
  React.useEffect(() => {
    let activeStream: MediaStream | null = null;
    let isActive = true;

    if (useWebcam && feedSource === 'camera' && selectedCameraId) {
      const selectedCam = cameras.find(c => c.id === selectedCameraId) || cameras[0];
      if (selectedCam && selectedCam.status === 'active') {
        try {
          if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error("navigator.mediaDevices is not available in this environment.");
          }
          navigator.mediaDevices.getUserMedia({ video: true })
            .then((stream) => {
              if (!isActive) {
                stream.getTracks().forEach(track => track.stop());
                return;
              }
              activeStream = stream;
              webcamStreamRef.current = stream;
              setHasWebcamStream(true);
              if (videoRef.current) {
                videoRef.current.srcObject = stream;
              }
              // Request desktop notification permission if supported
              if ('Notification' in window && Notification.permission === 'default') {
                Notification.requestPermission();
              }
            })
            .catch((err) => {
              console.error("Failed to access webcam:", err instanceof Error ? err.message : String(err));
              setUseWebcam(false);
            });
        } catch (err) {
          console.error("Webcam stream access exception:", err instanceof Error ? err.message : String(err));
          setUseWebcam(false);
        }
      }
    }

    return () => {
      isActive = false;
      if (videoRef.current) {
        try {
          videoRef.current.srcObject = null;
        } catch (_) {}
      }
      if (activeStream) {
        activeStream.getTracks().forEach(track => track.stop());
      }
      if (webcamStreamRef.current) {
        webcamStreamRef.current.getTracks().forEach(track => track.stop());
      }
      webcamStreamRef.current = null;
      setHasWebcamStream(false);
    };
  }, [useWebcam, feedSource, selectedCameraId, cameras]);

  // 2. Client-side Real-time AI Fire & Smoke Computer Vision Analyzer + Web Audio Buzzer Warning Synth
  React.useEffect(() => {
    let intervalId: any = null;
    let audioCtx: AudioContext | null = null;
    let oscillator: OscillatorNode | null = null;
    let modulator: OscillatorNode | null = null;
    let modGain: GainNode | null = null;
    let distortion: WaveShaperNode | null = null;
    let gainNode: GainNode | null = null;
    let pulseTimer: any = null;

    // Warning sound synthesizer
    const startSiren = () => {
      if (buzzerMuted) return;
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!audioCtx) {
          audioCtx = new AudioContextClass();
        }
        if (audioCtx.state === 'suspended') {
          audioCtx.resume();
        }
        if (!oscillator) {
          // Initialize dual-oscillator FM synthesis plus overdrive distortion
          oscillator = audioCtx.createOscillator();
          modulator = audioCtx.createOscillator();
          modGain = audioCtx.createGain();
          distortion = audioCtx.createWaveShaper();
          gainNode = audioCtx.createGain();

          // Carrier oscillator - deep growling industrial baseline
          oscillator.type = 'sawtooth';
          oscillator.frequency.setValueAtTime(140, audioCtx.currentTime); // Deep commanding alarm core

          // Modulator oscillator - creates severe intermodulation roughness (vibration-frequency)
          modulator.type = 'sawtooth';
          modulator.frequency.setValueAtTime(197, audioCtx.currentTime); // Dissonant relationship to base frequency

          // Extreme modulation depth for a gritty, chaotic, broken gear buzz
          modGain.gain.setValueAtTime(1500, audioCtx.currentTime);

          // Route modulator to modulate the carrier's frequency
          modulator.connect(modGain);
          modGain.connect(oscillator.frequency);

          // Symmetrical high-overdrive wave shaper for extreme saturation and clip-buzz
          const makeDistortionCurve = (amount: number) => {
            const k = amount;
            const n_samples = 44100;
            const curve = new Float32Array(n_samples);
            const deg = Math.PI / 180;
            for (let i = 0; i < n_samples; ++i) {
              const x = (i * 2) / n_samples - 1;
              // Saturated sigmoid curve with extreme folding tendency
              const val = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
              // Slightly clip at bounds to emulate hard speaker-box saturation
              curve[i] = Math.max(-0.95, Math.min(0.95, val * 1.5));
            }
            return curve;
          };
          distortion.curve = makeDistortionCurve(180);
          distortion.oversample = '4x';

          // Route main carrier to distortion, then to envelope gain, and finally destination
          oscillator.connect(distortion);
          distortion.connect(gainNode);
          gainNode.connect(audioCtx.destination);

          // Start both signal sources
          modulator.start();
          oscillator.start();

          let count = 0;
          pulseTimer = setInterval(() => {
            if (oscillator && gainNode && audioCtx) {
              const now = audioCtx.currentTime;
              // High-intensity rapid mechanical buzzer pulsing structure
              const isBeepPhase = count % 2 === 0;
              if (isBeepPhase) {
                // Pitch kick for dramatic impact to simulate power surge starter sound
                oscillator.frequency.setValueAtTime(145, now);
                oscillator.frequency.linearRampToValueAtTime(125, now + 0.15);

                // Heavy-duty instant-clipping attack envelope
                gainNode.gain.cancelScheduledValues(now);
                gainNode.gain.setValueAtTime(0, now);
                gainNode.gain.linearRampToValueAtTime(0.35, now + 0.005); // Brutal snappy attack
                gainNode.gain.linearRampToValueAtTime(0.25, now + 0.14);  // Heavy power sustained load hum
                gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.19); // Sudden mechanical release
              } else {
                // Sharp cut slice
                gainNode.gain.cancelScheduledValues(now);
                gainNode.gain.setValueAtTime(0, now);
              }
              count++;
            }
          }, 200); // 200ms rapid pacing
        }
      } catch (err) {
        console.warn("Web Audio API not supported/permitted yet:", err instanceof Error ? err.message : String(err));
      }
    };

    const stopSiren = () => {
      if (pulseTimer) {
        clearInterval(pulseTimer);
        pulseTimer = null;
      }
      if (oscillator) {
        try {
          oscillator.stop();
        } catch (e) {}
        oscillator = null;
      }
      if (modulator) {
        try {
          modulator.stop();
        } catch (e) {}
        modulator = null;
      }
      if (modGain) {
        try {
          modGain.disconnect();
        } catch (e) {}
        modGain = null;
      }
      if (distortion) {
        try {
          distortion.disconnect();
        } catch (e) {}
        distortion = null;
      }
      if (gainNode) {
        try {
          gainNode.disconnect();
        } catch (e) {}
        gainNode = null;
      }
    };

    if (useWebcam && feedSource === 'camera' && hasWebcamStream) {
      // Create offscreen sampling canvas for analysis
      const canvas = document.createElement('canvas');
      canvas.width = 100;
      canvas.height = 75;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      intervalId = setInterval(() => {
        try {
          const video = videoRef.current;
          if (!video || video.paused || video.ended) {
            if (manualOverrideTrigger) {
              setFireProbability(97.2);
              setIsFireTriggered(true);
              setFireBbox({ x: 30, y: 25, w: 40, h: 50 });
              startSiren();
            } else {
              setFireProbability(0);
              setIsFireTriggered(false);
              setFireBbox(null);
              stopSiren();
            }
            return;
          }

          if (ctx) {
            // Safety guard: ensure video element is ready and has valid dimensions
            if (video.videoWidth === 0 || video.videoHeight === 0) {
              return;
            }
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            
            const pixels = imgData.data;
            let flamePixelCount = 0;
            let minX = canvas.width;
            let maxX = 0;
            let minY = canvas.height;
            let maxY = 0;

            // Process the pixel feed (Skip bytes for extremely fast canvas loop performance)
            for (let i = 0; i < pixels.length; i += 4) {
              const r = pixels[i];
              const g = pixels[i + 1];
              const b = pixels[i + 2];

              // Heuristic filter targeting warm flame colors (high red, medium green, low blue)
              const isFlameColor = r > 165 && g > 80 && b < 105 && r > g + 40 && g > b + 15;

              if (isFlameColor) {
                flamePixelCount++;
                const pixelIndex = i / 4;
                const x = pixelIndex % canvas.width;
                const y = Math.floor(pixelIndex / canvas.width);

                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
              }
            }

            const percentFound = (flamePixelCount / (canvas.width * canvas.height)) * 100;
            const finalPercent = manualOverrideTrigger ? Math.max(percentFound, 85.0) : percentFound;

            // If more than 0.35% of camera frame pixels match warm flame profiles, or override is on
            if (finalPercent > 0.35 || manualOverrideTrigger) {
              const prob = Math.min(Math.round(80 + finalPercent * 8), 99.7);
              setFireProbability(prob);
              setIsFireTriggered(true);
              startSiren();

              let bbox;
              if (manualOverrideTrigger && percentFound <= 0.35) {
                // Simulated central warning frame
                bbox = { x: 35, y: 30, w: 30, h: 40 };
              } else {
                bbox = {
                  x: Math.round((minX / canvas.width) * 100),
                  y: Math.round((minY / canvas.height) * 100),
                  w: Math.round(((maxX - minX) / canvas.width) * 100),
                  h: Math.round(((maxY - minY) / canvas.height) * 100)
                };
                // Add bounds padding
                bbox.x = Math.max(0, bbox.x - 4);
                bbox.y = Math.max(0, bbox.y - 4);
                bbox.w = Math.min(100 - bbox.x, bbox.w + 8);
                bbox.h = Math.min(100 - bbox.y, bbox.h + 8);
              }
              setFireBbox(bbox);
            } else {
              setFireProbability(0);
              setIsFireTriggered(false);
              setFireBbox(null);
              stopSiren();
            }
          }
        } catch (err) {
          // Decouple error logging to ensure circular references are never serialized
          console.warn("Failsafe: video frame retrieval deferred: ", err instanceof Error ? err.message : String(err));
        }
      }, 200);
    } else {
      setFireProbability(0);
      setIsFireTriggered(false);
      setFireBbox(null);
      stopSiren();
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
      stopSiren();
    };
  }, [useWebcam, feedSource, hasWebcamStream, manualOverrideTrigger, buzzerMuted]);

  // 3. Automated Force Scan & Cellular Link / Toast Dispatch Controller
  React.useEffect(() => {
    if (isFireTriggered) {
      // Automatic rising-edge manual system scan trigger!
      if (incidentStatus === 'resolved') {
        onTriggerSimulation();
      }

      // Add a clean state notification toast to list
      const toastId = Math.random().toString(36).substring(2, 9);
      const newToast = {
        id: toastId,
        message: "🔥 SENTINEL DANGER DETECTED",
        sub: `Sentinel Cam Node identified continuous fire/smoke thermal signals (Confidence: ${fireProbability || 94}%). System Scanners and Drone Dispatch initiated.`,
        timestamp: new Date().toLocaleTimeString()
      };
      setActiveToasts(prev => [newToast, ...prev].slice(0, 4));

      // Setup simulated Ranger cellular SMS Link
      const cameraName = cameras.find(c => c.id === selectedCameraId)?.id || 'CAM-1';
      const smsBody = `🚨 FIREWATCH SYSTEM EMERGENCY ALERT:\n====================\nFlame & dense thermal anomaly identified on live stream from Unit ${cameraName}.\n\nConfidence ID: AI-CV-${fireProbability || 95}%\nLocation Coordinates: 11.6664° N, 76.6253° E\nAction: Manual Forest Node Scan Triggered. Incident active. Emergency teams alert code issued.`;
      
      setMobileNotifyMsg(smsBody);
      setShowMobileNotify(true);

      // Web Browser Notification System push
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification("🔥 FIREWATCH CRITICAL WARNING", {
          body: `Siren activated: Active flame signatures scanned on Sentinel unit ${cameraName}! Drone dispatch triggered.`,
          tag: 'firewatch-alert'
        });
      }

      // Dispatch auto-forward copy to real phone if configured or if twilio is active
      const savedPhone = localStorage.getItem('firewatch-real-sms-phone') || '';
      const isTwilioActive = twilioConfig?.twilioConfigured || savedPhone.trim() !== '';
      if (isTwilioActive) {
        sendRealSMSToPhone(savedPhone, smsBody);
      }
    }
  }, [isFireTriggered]);

  const current = sensorHistory[sensorHistory.length - 1];
  const selectedCamera = cameras.find(c => c.id === selectedCameraId) || cameras[0];

  const cameraModeLabels: Record<CameraView, string> = {
    optical: 'Optical (RGB)',
    thermal: 'IR Thermal',
    lidar: 'LIDAR Scanning',
    wide: 'Wide-Angle Survey',
    satellite: 'Bandipur Satellite'
  };

  return (
    <>
      {/* Dynamic In-App Website Notification Toast Stack */}
      <div className="fixed top-6 right-6 z-50 flex flex-col gap-3 min-w-[320px] max-w-[420px] pointer-events-none text-left">
        <AnimatePresence>
          {activeToasts.map(toast => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
              className="pointer-events-auto bg-black/95 border border-red-500/50 rounded-2xl p-4 shadow-[0_10px_30px_rgba(239,68,68,0.25)] backdrop-blur-md flex gap-3 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-1.5 h-full bg-red-600 animate-pulse" />
              <div className="p-1 bg-red-500/10 border border-red-500/30 rounded-xl text-red-500 flex items-center justify-center shrink-0 w-10 h-10">
                <Bell className="animate-bounce" size={18} />
              </div>
              <div className="flex-1 min-w-0 pr-6">
                <p className="font-mono text-[10px] text-red-400 font-bold tracking-widest uppercase mb-0.5">{toast.message}</p>
                <p className="text-[11px] text-[#A3A7B0] font-mono leading-relaxed">{toast.sub}</p>
                <p className="text-[9px] text-zinc-500 font-mono mt-1.5 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  DISPATCHED: {toast.timestamp}
                </p>
              </div>
              <button
                onClick={() => setActiveToasts(prev => prev.filter(t => t.id !== toast.id))}
                className="absolute top-3 right-3 text-zinc-500 hover:text-white text-[11px] font-mono p-1 transition-colors"
                title="Dismiss warning notification toast"
              >
                ✕
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Simulated Cellular Phone Emergency SMS Link */}
      <AnimatePresence>
        {showMobileNotify && (
          <motion.div
            initial={{ opacity: 0, y: 100, x: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, x: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-50 bg-[#121216] border-2 border-zinc-800 rounded-3xl p-4 w-[310px] shadow-[0_15px_40px_rgba(0,0,0,0.65)] font-sans text-left"
          >
            {/* Phone Header simulated HUD */}
            <div className="flex justify-between items-center text-[10px] text-zinc-500 font-mono mb-2.5 uppercase tracking-wider">
              <div className="flex items-center gap-1.5">
                <Smartphone size={12} className="text-purple-400" />
                <span>RANGER CARRIER LINK</span>
              </div>
              <div className="flex items-center gap-1 font-bold">
                <span>5G</span>
                <div className="w-4 h-2.5 bg-green-500/40 rounded-xs border border-green-400/45 flex items-center p-px">
                  <div className="w-full h-full bg-green-400 rounded-2xs" />
                </div>
              </div>
            </div>

            {/* Notification Card Bubble */}
            <div className="bg-[#1a1a24] border border-red-500/30 rounded-2xl p-3 relative overflow-hidden shadow-inner">
              <div className="absolute top-1.5 right-2 animate-pulse flex items-center gap-1 text-[8px] font-mono text-red-500 font-black tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
                LIVE SMS
              </div>
              <div className="flex gap-2">
                <span className="text-lg">🚨</span>
                <div>
                  <div className="text-[10px] font-bold text-red-400 uppercase tracking-wide">BROADCAST RECEIVED</div>
                  <div className="text-[8px] text-zinc-400 font-mono mt-0.5 leading-normal">
                    vvce25cse0349@vvce.ac.in
                  </div>
                </div>
              </div>
              <div className="text-[10px] text-zinc-200 font-mono border-t border-zinc-800 mt-2.5 pt-2 whitespace-pre-line leading-relaxed">
                {mobileNotifyMsg}
              </div>
            </div>

             {/* Real SMS configuration panel inside the simulated phone */}
            <div className="mt-4 border-t border-zinc-900 pt-3.5 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <label className="text-[9px] font-bold text-zinc-400 font-mono uppercase tracking-wider block">
                  🔴 LINK PHYSICAL PHONE (REAL SMS)
                </label>
                {realPhoneNumber && (
                  <span className="text-[8px] font-mono text-green-500 flex items-center gap-1 font-black">
                    <span className="w-1 h-1 rounded-full bg-green-500 animate-pulse" />
                    LINKED
                  </span>
                )}
              </div>
              
              <div className="flex gap-1.5">
                <input
                  type="text"
                  placeholder="e.g. +919035xxxxxx"
                  value={realPhoneNumber}
                  onChange={(e) => {
                    const val = e.target.value;
                    setRealPhoneNumber(val);
                    localStorage.setItem('firewatch-real-sms-phone', val);
                  }}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-1.5 text-white text-[10px] font-mono flex-1 focus:outline-none focus:border-purple-500 placeholder-zinc-650"
                />
                <button
                  onClick={() => {
                    sendRealSMSToPhone(realPhoneNumber, `🚨 FIREWATCH SMS LINK TEST\n====================\nConnection successful! Your physical device has been linked to the Real-Time Firewatch Alerting System.\n\nYou will now receive actual SMS push notifications when wildfires are scanned.`);
                  }}
                  disabled={smsStatus.state === 'sending'}
                  className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 disabled:hover:bg-purple-600 px-3 py-1.5 rounded-xl text-white font-mono text-[9px] font-bold transition-colors uppercase cursor-pointer shrink-0"
                  title="Test link by sending a real handshake SMS"
                >
                  {smsStatus.state === 'sending' ? 'Sending' : 'TEST LINK'}
                </button>
              </div>

              {/* Verified caller ID loader from Twilio */}
              {twilioConfig?.twilioConfigured && twilioConfig.verifiedNumbers && twilioConfig.verifiedNumbers.length > 0 && (
                <div className="text-[8px] font-mono text-zinc-400 mt-0.5 flex flex-col gap-1 bg-zinc-950 p-2 rounded-xl border border-zinc-900 leading-normal">
                  <div className="flex items-center justify-between">
                    <span className="text-[7.5px] font-bold text-indigo-400 uppercase">⚡ REGISTERED CALLER ID DETECTED</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                  </div>
                  <div className="flex items-center justify-between gap-1 mt-0.5">
                    <span className="text-zinc-300 font-bold truncate select-all">{twilioConfig.verifiedNumbers[0]}</span>
                    {realPhoneNumber !== twilioConfig.verifiedNumbers[0] && (
                      <button
                        onClick={() => {
                          setRealPhoneNumber(twilioConfig.verifiedNumbers[0]);
                          localStorage.setItem('firewatch-real-sms-phone', twilioConfig.verifiedNumbers[0]);
                        }}
                        className="bg-indigo-950 hover:bg-indigo-900 text-indigo-300 px-1.5 py-0.5 text-[7px] uppercase font-black rounded border border-indigo-900 cursor-pointer shrink-0"
                      >
                        Auto-Fill
                      </button>
                    )}
                  </div>
                </div>
              )}

              {smsStatus.state === 'sending' && (
                <div className="text-[9px] font-mono text-amber-500 animate-pulse flex items-center gap-1.5 mt-0.5 bg-amber-950/10 border border-amber-900/30 p-2 rounded-xl">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping shrink-0" />
                  Dispatching actual cellular carrier request...
                </div>
              )}

              {smsStatus.state === 'success' && (
                <div className="text-[9px] font-mono text-green-400 leading-normal mt-0.5 bg-green-950/20 border border-green-900/40 p-2 rounded-xl flex flex-col gap-1">
                  <p className="font-bold flex items-center gap-1">✔ SMS Delivered successfully!</p>
                  <p className="text-[8px] text-zinc-400 leading-normal">
                    Message SID: <span className="select-all font-sans">{smsStatus.sid}</span>
                  </p>
                </div>
              )}

              {smsStatus.state === 'error' && (
                <div className="text-[9px] font-mono text-red-400 leading-normal mt-0.5 bg-red-950/20 border border-red-900/40 p-2 rounded-xl flex flex-col gap-1">
                  <p className="font-bold">✖ SMS Dispatch Failed</p>
                  <p className="text-[8px] text-zinc-400 font-sans leading-relaxed">
                    {smsStatus.message}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-3.5 flex gap-2">
              <button
                onClick={() => setShowMobileNotify(false)}
                className="flex-1 py-1.5 text-center bg-zinc-800 hover:bg-zinc-750 text-white text-[9px] font-bold uppercase tracking-widest rounded-xl transition-colors cursor-pointer"
              >
                DISMISS MOBILE ALERT
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="p-8 h-full flex flex-col gap-8 transition-colors duration-300">
        {/* Live Feed and Main Chart Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 flex-1 min-h-[500px]">
        {/* Drone Feed Placeholder */}
        <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden flex flex-col relative group">
          <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)] whitespace-nowrap">
            <div className="flex items-center bg-[var(--bg-primary)] p-0.5 rounded-lg border border-[var(--border-color)] shadow-inner relative overflow-hidden">
              <button 
                onClick={() => setFeedSource('drone')}
                className={`relative px-3 py-1 text-[9px] font-black uppercase tracking-[0.1em] rounded-md flex items-center gap-1.5 transition-colors duration-200 z-10 ${
                  feedSource === 'drone' 
                    ? 'text-white' 
                    : 'text-[var(--text-muted)] hover:text-[var(--text-secondary)]'
                }`}
              >
                {feedSource === 'drone' && (
                  <motion.div
                    layoutId="activeFeedIndicator"
                    className="absolute inset-0 bg-orange-600 rounded-md -z-10 shadow-sm"
                    transition={{ type: 'spring', stiffness: 380, damping: 28 }}
                  />
                )}
                <Video size={11} /> Drone Feed
              </button>
              <button 
                onClick={() => setFeedSource('camera')}
                className={`relative px-3 py-1 text-[9px] font-black uppercase tracking-[0.1em] rounded-md flex items-center gap-1.5 transition-colors duration-200 z-10 ${
                  feedSource === 'camera' 
                    ? 'text-white' 
                    : 'text-[var(--text-muted)] hover:text-[var(--text-secondary)]'
                }`}
              >
                {feedSource === 'camera' && (
                  <motion.div
                    layoutId="activeFeedIndicator"
                    className="absolute inset-0 bg-purple-600 rounded-md -z-10 shadow-sm"
                    transition={{ type: 'spring', stiffness: 380, damping: 28 }}
                  />
                )}
                <Camera size={11} /> Sentinel Cam
              </button>
            </div>
            
            <div className="flex items-center gap-3">
              {feedSource === 'drone' ? (
                <div className={`flex items-center gap-2 text-[10px] font-mono bg-green-500/5 px-2 py-0.5 rounded border border-green-500/20 ${incidentStatus !== 'resolved' ? 'text-orange-500 border-orange-500/20' : 'text-green-500'}`}>
                   <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${incidentStatus !== 'resolved' ? 'bg-orange-500' : 'bg-green-500'}`} />
                   {incidentStatus !== 'resolved' ? 'MISSION ACTIVE' : 'LIVE'}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    selectedCamera?.status === 'active' ? 'bg-[#c084fc] shadow-[0_0_6px_#c084fc]' :
                    selectedCamera?.status === 'maintenance' ? 'bg-orange-500 shadow-[0_0_6px_rgba(249,115,22,0.5)]' :
                    'bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.5)]'
                  }`} />
                  <span className="text-[10px] font-black font-mono uppercase tracking-widest text-[var(--text-secondary)]">
                    {selectedCamera?.status?.toUpperCase() || 'ACTIVE'}
                  </span>
                </div>
              )}
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className={`p-1 rounded hover:bg-[var(--text-primary)]/10 transition-colors ${showSettings ? 'text-orange-500 bg-[var(--bg-tertiary)]' : 'text-[var(--text-muted)]'}`}
              >
                <Settings size={14} />
              </button>
            </div>
          </div>

          <AnimatePresence initial={false}>
            {feedSource === 'camera' && (
              <motion.div 
                key="camSelectorHeader"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden w-full border-b border-[var(--border-color)] bg-[var(--bg-tertiary)]"
              >
                <div className="px-4 py-2 flex flex-wrap items-center justify-between gap-3 shrink-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-black font-mono text-[var(--text-muted)] uppercase tracking-widest mr-1">Select Unit</span>
                    <select 
                      value={selectedCameraId}
                      onChange={(e) => {
                        setSelectedCameraId(e.target.value);
                      }}
                      className="bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg px-2 py-1 text-[10px] font-mono font-bold uppercase text-[var(--text-primary)] outline-none focus:border-purple-500 min-w-[130px]"
                    >
                      {cameras.map((cam) => (
                        <option key={cam.id} value={cam.id} className="bg-[var(--bg-secondary)] text-[var(--text-primary)]">
                          {cam.id} — {cam.model} ({cam.status.toUpperCase()})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* WEBCAM OVERRIDE TOGGLE */}
                  {selectedCamera?.status === 'active' && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => setUseWebcam(prev => !prev)}
                        className={`relative px-2.5 py-1 text-[9px] font-black uppercase tracking-[0.1em] rounded-lg transition-all flex items-center gap-1.5 border overflow-hidden ${
                          useWebcam 
                            ? 'border-purple-500 text-white shadow-[0_0_8px_rgba(168,85,247,0.5)]' 
                            : 'bg-[var(--bg-primary)] border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-secondary)] hover:border-[var(--text-muted)]'
                        }`}
                      >
                        {useWebcam && (
                          <motion.span
                            layoutId="webcamActiveIndicator"
                            className="absolute inset-0 bg-purple-600 -z-10"
                            transition={{ duration: 0.2 }}
                          />
                        )}
                        <span className={`w-1.5 h-1.5 rounded-full ${useWebcam ? 'bg-green-400 animate-pulse' : 'bg-zinc-500'}`} />
                        {useWebcam ? 'Webcam Active' : 'Use Webcam Feed'}
                      </button>

                      {useWebcam && (
                        <>
                          {/* SIREN AUDIO MUTE / ACTIVE TOGGLER */}
                          <button
                            type="button"
                            onClick={() => setBuzzerMuted(prev => !prev)}
                            className={`px-2 py-1 text-[9px] font-mono font-bold uppercase tracking-wider rounded-lg border flex items-center gap-1.5 transition-all ${
                              buzzerMuted
                                ? 'bg-amber-950/40 border-amber-800 text-amber-500 hover:bg-amber-900/10'
                                : 'bg-red-950/40 border-red-800 text-red-400 font-bold animate-pulse'
                            }`}
                            title={buzzerMuted ? "Click to enable audio buzzer" : "Click to mute warning siren"}
                          >
                            {buzzerMuted ? <VolumeX size={11} /> : <Volume2 size={11} />}
                            {buzzerMuted ? 'Buzzer Muted' : 'Siren Active'}
                          </button>

                          {/* SIMULATED INJECTED FLAME TESTER */}
                          <button
                            type="button"
                            onClick={() => setManualOverrideTrigger(prev => !prev)}
                            className={`px-2 py-1 text-[9px] font-mono font-bold uppercase tracking-wider rounded-lg border flex items-center gap-1.5 transition-all ${
                              manualOverrideTrigger
                                ? 'bg-red-600 border-red-400 text-white font-black shadow-[0_0_8px_rgba(239,68,68,0.5)]'
                                : 'bg-zinc-900 border-zinc-700 text-zinc-400 hover:bg-zinc-850 hover:text-white'
                            }`}
                            title="Simulate webcam capturing virtual wildfire fire to check notifications"
                          >
                            <Cpu size={11} />
                            {manualOverrideTrigger ? "Flame Injected" : "Simulate Flame"}
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="flex-1 bg-black relative flex items-center justify-center overflow-hidden min-h-[380px]">
             {cameraView === 'satellite' ? (
                // Google Satellite Map for Bandipur Forest
                !hasValidKey ? (
                  // Elegant splash screen when no valid key is present (with instructions)
                  <div className="absolute inset-0 bg-[#0A0A0A] flex flex-col items-center justify-center p-6 text-center z-10 overflow-y-auto">
                    <Layers className="w-10 h-10 text-orange-500 mb-3 animate-pulse" />
                    <h3 className="text-base font-bold text-white uppercase tracking-wider mb-2">Google Maps API Key Required</h3>
                    <p className="text-xs text-[#8E9299] max-w-[320px] leading-relaxed mb-4">
                      Add your key to enable live high-resolution satellite imagery & monitoring of the Bandipur Forest region.
                    </p>
                    <div className="bg-[#151619] border border-white/5 rounded-xl p-3 text-left w-full max-w-[320px] space-y-2 text-[10px] text-[#A3A7B0] font-mono leading-normal">
                      <p className="font-bold text-white uppercase tracking-wider text-[9px] text-orange-400 mb-1">Configuration Steps:</p>
                      <p>1. <a href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais" target="_blank" rel="noopener noreferrer" className="text-orange-500 hover:underline">Get an API Key</a></p>
                      <p>2. Open <strong>Settings</strong> (⚙️ gear icon, top-right of screen)</p>
                      <p>3. Select <strong>Secrets</strong></p>
                      <p>4. Save as <code>GOOGLE_MAPS_PLATFORM_KEY</code></p>
                    </div>
                    <div className="mt-4 text-[9px] text-[#555] font-mono mt-2">
                      The app rebuilds automatically once key is added.
                    </div>
                  </div>
                ) : (
                  // Render the actual React Google Map (advanced marker and zoom setup)
                  <div className="absolute inset-0 w-full h-full">
                    <APIProvider apiKey={API_KEY} version="weekly">
                      <Map
                        center={
                          feedSource === 'camera' && selectedCamera
                            ? { lat: 11.6664 + (selectedCamera.y - 300) / 15000, lng: 76.6253 + (selectedCamera.x - 400) / 15000 }
                            : bandipurCenter
                        }
                        defaultZoom={11}
                        mapTypeId="hybrid"
                        mapId="DEMO_MAP_ID"
                        disableDefaultUI={true}
                        zoomControl={true}
                        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                        style={{width: '100%', height: '100%'}}
                      >
                        {MAP_MARKERS.map(marker => (
                          <AdvancedMarker 
                            key={marker.id} 
                            position={{ lat: marker.lat, lng: marker.lng }}
                            onClick={() => setSelectedMapMarker(marker)}
                            title={marker.name}
                          >
                            <div className="cursor-pointer group flex flex-col items-center">
                              {/* Pulse wave behind point */}
                              <div className="absolute w-8 h-8 rounded-full bg-orange-500/30 animate-ping" style={{ animationDuration: '3s' }} />
                              <Pin 
                                background={marker.status === 'Active' ? '#f97316' : '#f59e0b'} 
                                borderColor="#fff" 
                                glyphColor="#fff"
                              />
                            </div>
                          </AdvancedMarker>
                        ))}

                        {/* Present Camera Marker on the map if viewing camera */}
                        {feedSource === 'camera' && selectedCamera && (
                          <AdvancedMarker 
                            position={{ 
                              lat: 11.6664 + (selectedCamera.y - 300) / 15000, 
                              lng: 76.6253 + (selectedCamera.x - 400) / 15000 
                            }}
                          >
                            <div className="relative flex items-center justify-center cursor-pointer">
                              <span className="absolute inline-flex h-10 w-10 rounded-full bg-purple-500/30 animate-pulse" />
                              <Pin background="#a855f7" borderColor="#fff" glyphColor="#fff" scale={1.1} />
                            </div>
                          </AdvancedMarker>
                        )}

                        {/* Fire incident hotspot marker if in simulation mode */}
                        {incidentLocation && (
                          <AdvancedMarker position={{ lat: 11.6664 + (Math.random() - 0.5) * 0.08, lng: 76.6253 + (Math.random() - 0.5) * 0.08 }}>
                            <div className="relative flex items-center justify-center">
                              <span className="absolute inline-flex h-12 w-12 rounded-full bg-red-600/40 animate-ping" style={{ animationDuration: '1.5s' }} />
                              <Pin background="#ef4444" borderColor="#fff" glyphColor="#fff" scale={1.2} />
                            </div>
                          </AdvancedMarker>
                        )}

                        {selectedMapMarker && (
                          <InfoWindow 
                            position={{ lat: selectedMapMarker.lat, lng: selectedMapMarker.lng }}
                            onCloseClick={() => setSelectedMapMarker(null)}
                          >
                            <div className="p-2 max-w-[200px] text-zinc-950 font-sans" style={{ color: '#09090b' }}>
                              <div className="text-[9px] font-bold text-orange-600 uppercase tracking-widest mb-1">{selectedMapMarker.id} · {selectedMapMarker.status}</div>
                              <h4 className="text-xs font-bold text-zinc-900 mb-1">{selectedMapMarker.name}</h4>
                              <p className="text-[10px] text-zinc-600 leading-snug mb-1">{selectedMapMarker.description}</p>
                              <div className="text-[9px] font-mono font-medium text-zinc-500">Telemetry: Bat {selectedMapMarker.battery}</div>
                            </div>
                          </InfoWindow>
                        )}
                      </Map>
                    </APIProvider>
                    
                    {/* Floating HUD controls on top of map */}
                    <div className="absolute bottom-4 left-4 z-10 bg-black/85 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10 flex flex-col gap-1 text-[10px] font-mono text-white pointer-events-none">
                      <div className="text-orange-400 font-bold uppercase tracking-wider text-[9px] mb-1">🛰️ SAT MONITORING</div>
                      <div>REGION: BANDIPUR FOREST</div>
                      {feedSource === 'camera' && selectedCamera ? (
                        <>
                          <div>UNIT: {selectedCamera.id}</div>
                          <div>LAT: {(11.6664 + (selectedCamera.y - 300) / 15000).toFixed(5)}° N</div>
                          <div>LNG: {(76.6253 + (selectedCamera.x - 400) / 15000).toFixed(5)}° E</div>
                        </>
                      ) : (
                        <>
                          <div>LAT: {bandipurCenter.lat.toFixed(5)}° N</div>
                          <div>LNG: {bandipurCenter.lng.toFixed(5)}° E</div>
                        </>
                      )}
                      <div className="text-green-400">FPS / STREAM: LIVE DATA LINK</div>
                    </div>
                  </div>
                )
             ) : (
                <>
                  {/* Video/Webcam Feed with filters based on cameraView */}
                  {feedSource === 'camera' && useWebcam && selectedCamera?.status === 'active' ? (
                    <>
                      <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        muted 
                        className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 -scale-x-100 ${
                          (cameraView === 'thermal' || incidentStatus === 'analyzing') ? 'grayscale contrast-200 invert' : 
                          cameraView === 'lidar' ? 'sepia' :
                          cameraView === 'wide' ? 'blur-[0.5px] scale-110 font-sans' :
                          'opacity-90'
                        }`}
                      />

                      {/* AI COMPUTER VISION SURFACE REAL-TIME DETECT BOUNDING BOX */}
                      {isFireTriggered && fireBbox && (
                        <div 
                          className="absolute pointer-events-none border-2 border-red-500 rounded z-30 animate-pulse"
                          style={{
                            left: `${100 - fireBbox.x - fireBbox.w}%`,
                            top: `${fireBbox.y}%`,
                            width: `${fireBbox.w}%`,
                            height: `${fireBbox.h}%`,
                            boxShadow: 'inset 0 0 16px rgba(239, 68, 68, 0.45), 0 0 10px rgba(239, 68, 68, 0.65)'
                          }}
                        >
                          <div className="absolute top-0 left-0 bg-red-600 border-b border-r border-red-500 text-white font-mono font-black text-[8px] sm:text-[9px] px-1.5 py-0.5 uppercase tracking-widest whitespace-nowrap rounded-br shadow-lg flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
                            CV-FLAME-MATCH: {fireProbability}%
                          </div>
                          <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-red-400" />
                          <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-red-400" />
                          <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-red-400" />
                          <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-red-400" />
                        </div>
                      )}

                      {/* RED ALERT SCREEN FLASH FOR REAL WEBCAM FLAME DETECTION */}
                      {isFireTriggered && (
                        <div className="absolute inset-0 pointer-events-none border-[6px] border-red-600/70 z-20 animate-pulse bg-red-600/5 mix-blend-color-burn">
                          <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-red-910 border border-red-500 text-white px-3 py-1 text-center rounded-full flex items-center gap-2 shadow-2xl backdrop-blur-md max-w-[90%] w-max bg-red-950/90">
                            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping inline-block shrink-0" />
                            <span className="font-mono text-[8px] sm:text-[9px] font-black tracking-[0.2em] uppercase text-red-100">AI DETECTED WILDFIRE RISK ON {selectedCamera.id}</span>
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <div 
                      className={`absolute inset-0 transition-all duration-700 bg-cover bg-center ${
                        (cameraView === 'thermal' || incidentStatus === 'analyzing') ? 'opacity-60 grayscale contrast-200 invert' : 
                        cameraView === 'lidar' ? 'opacity-30 sepia hue-rotate-180 brightness-50' :
                        cameraView === 'wide' ? 'opacity-50 blur-[1px] scale-110' :
                        'opacity-80'
                      }`}
                      style={{ backgroundImage: `url(${bandipurSatelliteImg})` }}
                    />
                  )}

                  {/* GLITCH/STATIC EFFECT IF CAMERA IS NOT ACTIVE */}
                  {feedSource === 'camera' && selectedCamera && selectedCamera.status !== 'active' && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] z-15 flex flex-col items-center justify-center p-6 text-center">
                      {/* Fake monitor static / scanning background overlay */}
                      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,_rgba(0,0,0,0.25)_50%),_linear-gradient(90deg,_rgba(255,0,0,0.06),_rgba(0,255,0,0.02),_rgba(0,0,255,0.06))] bg-[length:100%_4px,_6px_100%] opacity-80" />
                      
                      <div className="relative bg-black/95 border border-red-500/30 p-5 rounded-2xl flex flex-col gap-4 max-w-sm w-full mx-auto shadow-2xl z-20">
                        <div className="flex items-center gap-2 text-red-500 font-mono">
                          <AlertTriangle size={16} className="animate-pulse" />
                          <span className="text-[10px] font-black tracking-widest uppercase">Telemetry Stream Error</span>
                        </div>

                        <div className="space-y-1.5 text-left border-y border-white/5 py-3">
                          <div className="text-xs font-bold text-white font-mono uppercase tracking-tight">Cam Sentinel {selectedCamera.id}</div>
                          <p className="text-[11px] text-[#A3A7B0] leading-relaxed font-mono">
                            {selectedCamera.status === 'offline' 
                              ? "Handshake Timeout on Central Perimeter Node. Signal noise exceeds 15% threshold causing telemetry feedback interruption." 
                              : "High optic index attenuation detected on receptor. PTZ motor rotation servo torque exceeds limits. Physical lens alignment required."}
                          </p>
                        </div>

                        <div className="flex items-center justify-between font-mono text-[9px] bg-[var(--bg-primary)] p-2.5 rounded border border-[var(--border-color)]">
                          <span className="text-[var(--text-muted)] uppercase font-bold">Recommended action:</span>
                          <span className="text-orange-400 font-bold uppercase">{selectedCamera.status === 'offline' ? "Manual Handshake Reset" : "Lens Calibration Reset"}</span>
                        </div>

                        {loggedTickets[selectedCamera.id] ? (
                          <div className="flex items-center justify-center gap-2 text-green-400 bg-green-500/10 px-3 py-2 rounded-lg border border-green-500/20 font-mono text-[10px] font-bold">
                            <CheckCircle2 size={12} />
                            TICKET LOGGED UNDER #{selectedCamera.id}-MT
                          </div>
                        ) : (
                          <button 
                            onClick={() => {
                              setIsRequestingTicket(true);
                              setTimeout(() => {
                                setLoggedTickets(prev => ({ ...prev, [selectedCamera.id]: true }));
                                setIsRequestingTicket(false);
                              }, 600);
                            }}
                            disabled={isRequestingTicket}
                            className="w-full py-2 bg-red-600 hover:bg-red-500 text-white text-[9px] font-black uppercase tracking-[0.2em] rounded-lg transition-all flex items-center justify-center gap-2"
                          >
                            {isRequestingTicket ? (
                              <>
                                <Zap size={11} className="animate-pulse" />
                                Processing override...
                              </>
                            ) : (
                              <>
                                <Wrench size={11} />
                                Log Emergency Ticket
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* Quality Indicators */}
                  <div className="absolute top-4 left-4 z-10 flex gap-2">
                     <div className="bg-black/60 backdrop-blur px-2 py-0.5 rounded text-[10px] font-mono text-white/60 border border-white/5">
                       {resolution}
                     </div>
                     <div className="bg-black/60 backdrop-blur px-2 py-0.5 rounded text-[10px] font-mono text-white/60 border border-white/5">
                       {frameRate}
                     </div>
                     {incidentStatus === 'analyzing' && feedSource === 'drone' && (
                       <motion.div 
                         initial={{ opacity: 0, x: -10 }}
                         animate={{ opacity: 1, x: 0 }}
                         className="bg-blue-600 px-2 py-0.5 rounded text-[10px] font-bold text-white border border-blue-400 animate-pulse"
                       >
                         RISK AI: ANALYZING THREAT...
                       </motion.div>
                     )}
                  </div>

                  {/* UI Overlays */}
                  <AnimatePresence mode="wait">
                    {feedSource === 'drone' ? (
                      <motion.div 
                        key="droneOverlay"
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.25, ease: 'easeOut' }}
                        className="absolute inset-0 border-[20px] border-transparent p-4 flex flex-col justify-between pointer-events-none z-10"
                      >
                         <div className="flex justify-between items-start">
                            <div className="flex flex-col gap-1">
                               <div className="bg-black/80 px-2 py-1 text-[10px] font-mono text-white flex items-center gap-2 border border-white/10 rounded">
                                 <Activity size={12} className="text-orange-500" />
                                 ALT: {incidentStatus === 'dispatching' ? '340m' : '120m'}
                               </div>
                               <div className="bg-black/80 px-2 py-1 text-[10px] font-mono text-white flex items-center gap-2 border border-white/10 rounded">
                                 <Wind size={12} className="text-blue-400" />
                                 SPEED: {incidentStatus === 'dispatching' ? '112km/h' : '45km/h'}
                               </div>
                            </div>

                            {incidentStatus !== 'resolved' && (
                              <motion.div 
                                 initial={{ opacity: 0, scale: 0.9 }}
                                 animate={{ opacity: 1, scale: 1 }}
                                 className="bg-orange-600/90 text-white px-4 py-2 border border-orange-400 rounded-lg shadow-xl"
                              >
                                 <div className="text-[10px] font-bold uppercase tracking-widest text-white/70">Current Mission</div>
                                 <div className="text-xl font-bold uppercase leading-tight">
                                    {incidentStatus === 'dispatching' ? 'DRONE DISPATCHED' : incidentStatus}
                                 </div>
                              </motion.div>
                            )}
                         </div>
                         
                         <div className="flex justify-center">
                            {incidentStatus === 'analyzing' ? (
                              <div className="relative">
                                 <div className="w-48 h-32 border-2 border-blue-500/50 rounded-lg flex items-center justify-center p-4">
                                    <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-blue-500" />
                                    <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-blue-500" />
                                    <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-blue-500" />
                                    <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-blue-500" />
                                    <div className="text-[10px] font-mono text-blue-400 animate-pulse text-center">
                                       PATTERN RECOGNITION IN PROGRESS<br/>
                                       PROBABILITY: {(Math.random() * 100).toFixed(1)}%
                                    </div>
                                 </div>
                              </div>
                            ) : (
                              <div className="w-24 h-24 border-2 border-white/10 rounded-full relative flex items-center justify-center">
                                 <div className="w-4 h-px bg-orange-500/50" />
                                 <div className="h-4 w-px bg-orange-500/50" />
                                 <div className="absolute inset-0 border-t-2 border-orange-500/20 rounded-full animate-spin-slow" />
                              </div>
                            )}
                         </div>

                         <div className="flex justify-between items-end">
                            <div className="text-[8px] font-mono text-white/40">
                               GRID: {incidentLocation ? `${incidentLocation.x.toFixed(0)}-${incidentLocation.y.toFixed(0)}` : 'SCANNING'}<br />
                               LAT: 11.66648° N        <br />
                               LNG: 76.62534° E
                            </div>
                            <div className="text-[10px] font-mono text-white flex gap-2 font-black">
                               <span className="text-orange-500">REC [●]</span>
                               04:22:12
                            </div>
                         </div>
                      </motion.div>
                    ) : (
                      // SENTINEL CAMERA HUD OVERLAYS FOR ACTIVE SCREEN
                      selectedCamera && selectedCamera.status === 'active' && (
                        <motion.div 
                          key="cameraOverlay"
                          initial={{ opacity: 0, scale: 0.98 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.98 }}
                          transition={{ duration: 0.25, ease: 'easeOut' }}
                          className="absolute inset-0 border-[20px] border-transparent p-4 flex flex-col justify-between pointer-events-none z-10 text-left"
                        >
                          <div className="flex justify-between items-start">
                            <div className="bg-black/80 px-2.5 py-1 text-[10px] font-mono text-white flex items-center gap-1.5 border border-white/10 rounded-md">
                              <Camera size={12} className="text-purple-400 animate-pulse" />
                              SENTINEL STREAM: {selectedCamera.id} · HD
                            </div>
                            <div className="flex items-center gap-1.5 bg-black/80 px-2 py-0.5 rounded border border-white/10 text-[9px] font-mono text-[#c084fc]">
                              <div className="w-1.5 h-1.5 rounded-full bg-[#c084fc] animate-pulse" />
                              LIVE SWEEP {selectedCamera.angle}°
                            </div>
                          </div>
                          
                          <div className="flex justify-center">
                             <div className="w-24 h-24 border border-purple-500/20 rounded-full relative flex items-center justify-center">
                                <div className="absolute inset-0 border-r-2 border-b-2 border-purple-500/40 rounded-full animate-spin-slow" />
                                <div className="w-3 h-3 rounded-full bg-purple-500/30 animate-pulse" />
                             </div>
                          </div>

                          <div className="flex justify-between items-end">
                            <div className="text-[8px] font-mono text-white/40 leading-relaxed">
                              MODEL: {selectedCamera.model}<br />
                              ZONE: {selectedCamera.zone}<br />
                              BATT: {selectedCamera.battery}%
                            </div>
                            <div className="text-[10px] font-mono text-white flex gap-2 font-black">
                              <span className="text-purple-400">REC [●]</span>
                              CAM_ONLINE_SEC
                            </div>
                          </div>
                        </motion.div>
                      )
                    )}
                  </AnimatePresence>

                  {/* Scanning Animation */}
                  <motion.div 
                    animate={{ y: [0, 400, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    className={`absolute top-0 left-0 w-full h-[2px] shadow-[0_0_15px] z-10 ${
                      feedSource === 'camera' 
                        ? 'bg-purple-500/40 shadow-purple-500/50' 
                        : 'bg-orange-500/30 shadow-orange-500/50'
                    }`}
                  />

                  {/* Settings Overlay */}
                  <AnimatePresence>
                    {showSettings && (
                      <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="absolute top-4 right-4 z-20 bg-black/95 backdrop-blur-xl border border-white/10 rounded-xl p-4 w-60 shadow-2xl text-left"
                      >
                         <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-3 border-b border-white/5 pb-1">Surveillance Settings</div>
                         
                         <div className="space-y-4">
                            <div>
                               <div className="text-[9px] text-[#8E9299] mb-1.5 uppercase font-medium">Resolution</div>
                               <div className="grid grid-cols-3 gap-1">
                                  {(['720p', '1080p', '4K'] as Resolution[]).map(res => (
                                    <button 
                                      key={res}
                                      onClick={() => setResolution(res)}
                                      className={`px-1 py-1 rounded text-[8px] font-mono transition-colors cursor-pointer ${resolution === res ? 'bg-orange-500 text-white' : 'bg-[#151619] text-[#555] hover:text-[#8E9299]'}`}
                                    >
                                      {res}
                                    </button>
                                  ))}
                               </div>
                            </div>

                            <div>
                               <div className="text-[9px] text-[#8E9299] mb-1.5 uppercase font-medium">Frame Rate</div>
                               <div className="grid grid-cols-2 gap-1">
                                  {(['30fps', '60fps'] as FrameRate[]).map(fps => (
                                    <button 
                                      key={fps}
                                      onClick={() => setFrameRate(fps)}
                                      className={`px-1 py-1 rounded text-[8px] font-mono transition-colors cursor-pointer ${frameRate === fps ? 'bg-blue-500 text-white' : 'bg-[#151619] text-[#555] hover:text-[#8E9299]'}`}
                                    >
                                      {fps}
                                    </button>
                                  ))}
                               </div>
                            </div>

                            <div className="pt-3.5 border-t border-white/10 flex flex-col gap-2 text-left">
                               <div className="text-[9px] text-zinc-400 font-bold uppercase tracking-wider">🔴 Physical SMS Link</div>
                               <input
                                 type="text"
                                 placeholder="e.g. +919035xxxxxx"
                                 value={realPhoneNumber}
                                 onChange={(e) => {
                                   const val = e.target.value;
                                   setRealPhoneNumber(val);
                                   localStorage.setItem('firewatch-real-sms-phone', val);
                                 }}
                                 className="w-full bg-[#151619] border border-white/10 rounded px-2 py-1.5 text-white text-[9px] font-mono focus:outline-none focus:border-purple-500 placeholder-zinc-700"
                               />
                               <button
                                 onClick={() => {
                                   sendRealSMSToPhone(realPhoneNumber, `🚨 FIREWATCH SMS LINK TEST\n====================\nConnection successful! Your device is now connected to the actual monitoring stream.`);
                                 }}
                                 disabled={smsStatus.state === 'sending'}
                                 className="w-full py-1.5 bg-purple-650 hover:bg-purple-600 disabled:opacity-50 text-white text-[8px] font-bold uppercase tracking-wider rounded transition-colors cursor-pointer"
                               >
                                 {smsStatus.state === 'sending' ? 'Sending...' : 'Test Connection'}
                               </button>

                               {/* Verified caller ID loader inside settings dropdown */}
                               {twilioConfig?.twilioConfigured && twilioConfig.verifiedNumbers && twilioConfig.verifiedNumbers.length > 0 && (
                                 <div className="text-[7.5px] font-mono text-zinc-400 mt-0.5 flex flex-col gap-1 bg-[#151619] p-2 rounded border border-white/5 leading-normal">
                                   <div className="flex items-center justify-between">
                                     <span className="text-[7px] font-bold text-indigo-400 uppercase">⚡ REGISTERED PHONE</span>
                                     <span className="w-1 h-1 rounded-full bg-green-500" />
                                   </div>
                                   <div className="flex items-center justify-between gap-1 mt-0.5">
                                     <span className="text-zinc-300 font-bold truncate select-all">{twilioConfig.verifiedNumbers[0]}</span>
                                     {realPhoneNumber !== twilioConfig.verifiedNumbers[0] && (
                                       <button
                                         onClick={() => {
                                           setRealPhoneNumber(twilioConfig.verifiedNumbers[0]);
                                           localStorage.setItem('firewatch-real-sms-phone', twilioConfig.verifiedNumbers[0]);
                                         }}
                                         className="bg-indigo-950 hover:bg-indigo-900 text-indigo-300 px-1.5 py-0.5 text-[6.5px] uppercase font-black rounded border border-indigo-900 cursor-pointer shrink-0"
                                       >
                                         Fill
                                       </button>
                                     )}
                                   </div>
                                 </div>
                               )}

                               {smsStatus.state === 'sending' && (
                                 <p className="text-[7.5px] font-mono text-amber-400 animate-pulse">Dispatching real SMS...</p>
                               )}
                               {smsStatus.state === 'success' && (
                                 <p className="text-[7.5px] font-mono text-green-400 leading-tight">✔ Sent! SID: {smsStatus.sid?.slice(0, 10)}...</p>
                               )}
                               {smsStatus.state === 'error' && (
                                 <p className="text-[7.5px] font-mono text-red-400 leading-tight bg-red-950/20 p-1 border border-red-900/40 rounded max-h-16 overflow-y-auto">✖ Error: {smsStatus.message}</p>
                               )}
                            </div>

                            <div className="pt-2 border-t border-white/5">
                               <button className="w-full py-1.5 bg-[#151619] hover:bg-[#222] text-[#8E9299] hover:text-white rounded text-[8px] font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2 cursor-pointer">
                                  <Maximize2 size={10} />
                                  Full Signal
                                </button>
                             </div>
                          </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </>
             )}
          </div>
          
          <div className="p-3 bg-[var(--bg-secondary)] border-t border-[var(--border-color)] flex gap-2 overflow-x-auto">
             {(['thermal', 'optical', 'lidar', 'wide', 'satellite'] as CameraView[]).map(mode => (
               <button 
                 key={mode}
                 onClick={() => setCameraView(mode)}
                 className={`px-3 py-1.5 rounded transition-all whitespace-nowrap text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 ${
                   cameraView === mode 
                   ? feedSource === 'camera'
                     ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(168,85,247,0.4)]'
                     : 'bg-orange-500 text-white shadow-[0_0_10px_rgba(249,115,22,0.3)]' 
                   : 'bg-[var(--bg-tertiary)] hover:bg-[var(--text-primary)]/10 text-[var(--text-secondary)]'
                 }`}
               >
                 {mode === 'thermal' && <Thermometer size={12} />}
                 {mode === 'optical' && <Eye size={12} />}
                 {mode === 'lidar' && <Radio size={12} />}
                 {mode === 'wide' && <Video size={12} />}
                 {mode === 'satellite' && <Layers size={12} />}
                 {cameraModeLabels[mode]}
               </button>
             ))}
          </div>
          
          <div className="p-6 border-t border-[var(--border-color)] bg-[var(--bg-secondary)]">
            <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)] mb-4">Surveillance Controls</div>
            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={onTriggerSimulation}
                disabled={incidentStatus !== 'resolved'}
                className="w-full py-3 bg-red-600 hover:bg-red-500 disabled:bg-[var(--bg-tertiary)] disabled:text-[var(--text-muted)] text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all flex items-center justify-center gap-3 shadow-lg shadow-red-600/10"
              >
                {incidentStatus === 'resolved' ? (
                  <>
                    <Zap size={14} />
                    Force Manual System Scan
                  </>
                ) : (
                  <>
                    <ShieldAlert size={14} className="animate-pulse" />
                    Simulation In Progress...
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Charts and Data Visuals */}
        <div className="lg:col-span-2 space-y-6">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Temperature History Chart */}
              <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl p-6">
                 <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      <Thermometer className="w-4 h-4 text-orange-500" />
                      <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-secondary)]">Ambient Temperature</span>
                    </div>
                    <span className="text-xl font-mono text-[var(--text-primary)]">{current?.temperature || '--'}°C</span>
                 </div>
                 <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={sensorHistory}>
                          <defs>
                            <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis hide dataKey="timestamp" />
                          <YAxis hide domain={['auto', 'auto']} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)' }}
                            itemStyle={{ color: '#f97316' }}
                            labelStyle={{ display: 'none' }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="temperature" 
                            stroke="#f97316" 
                            strokeWidth={2}
                            fillOpacity={1} 
                            fill="url(#tempGradient)" 
                            isAnimationActive={false}
                          />
                       </AreaChart>
                    </ResponsiveContainer>
                 </div>
              </div>

              {/* Humidity History Chart */}
              <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl p-6">
                 <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                       <Droplets className="w-4 h-4 text-blue-400" />
                       <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-secondary)]">Humidity Levels</span>
                    </div>
                    <span className="text-xl font-mono text-[var(--text-primary)]">{current?.humidity || '--'}%</span>
                 </div>
                 <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={sensorHistory}>
                          <defs>
                            <linearGradient id="humGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#60a5fa" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis hide dataKey="timestamp" />
                          <YAxis hide domain={['auto', 'auto']} />
                          <Tooltip 
                             contentStyle={{ backgroundColor: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)' }}
                             itemStyle={{ color: '#60a5fa' }}
                             labelStyle={{ display: 'none' }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="humidity" 
                            stroke="#60a5fa" 
                            strokeWidth={2}
                            fillOpacity={1} 
                            fill="url(#humGradient)" 
                            isAnimationActive={false}
                          />
                       </AreaChart>
                    </ResponsiveContainer>
                 </div>
              </div>
           </div>

           {/* Detailed Sensors Grid */}
           <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)]">
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4 text-[var(--text-secondary)]" />
                  <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-secondary)]">Sensor Array Status</span>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y md:divide-y-0 divide-[var(--border-color)]">
                 <SensorItem label="Smoke Level" value={`${current?.smokeLevel.toFixed(1)} ppm`} status="NORMAL" />
                 <SensorItem label="CO2 Concentration" value="412 ppm" status="SAFE" />
                 <SensorItem label="Soil Moisture" value="34%" status="LOW" color="text-orange-400" />
                 <SensorItem label="Wind Dir" value="S-SW" status="STEADY" />
              </div>
           </div>
        </div>
      </div>
    </div>
    </>
  );
}

function SensorItem({ label, value, status, color = "text-[var(--text-primary)]" }: any) {
  return (
    <div className="p-6">
       <div className="text-[10px] uppercase font-bold tracking-widest text-[var(--text-muted)] mb-2">{label}</div>
       <div className={`text-xl font-mono mb-1 ${color}`}>{value}</div>
       <div className="text-[9px] font-bold text-green-500/80 bg-green-500/5 px-2 py-0.5 rounded-full inline-block border border-green-500/10">
         {status}
       </div>
    </div>
  );
}
