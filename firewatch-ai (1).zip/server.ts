import express from "express";
import path from "path";
import twilio from "twilio";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware to parse incoming JSON bodies
  app.use(express.json());

  // API to fetch SMS configuration helper (for auto-filling target phone)
  app.get("/api/sms-config", async (req, res) => {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const fromNumber = process.env.TWILIO_PHONE_NUMBER;

    let defaultToNumber = process.env.TWILIO_TO_PHONE_NUMBER || "";
    let verifiedNumbers: string[] = [];
    let autoDetected = false;

    if (accountSid && authToken && fromNumber) {
      try {
        const client = twilio(accountSid, authToken);
        const callerIds = await client.outgoingCallerIds.list({ limit: 10 });
        verifiedNumbers = callerIds.map(c => c.phoneNumber).filter(Boolean) as string[];
        
        if (!defaultToNumber && verifiedNumbers.length > 0) {
          defaultToNumber = verifiedNumbers[0];
          autoDetected = true;
        }
      } catch (err: any) {
        console.warn("Could not fetch outgoing status from Twilio trial configs:", err.message || err);
      }
    }

    res.json({
      twilioConfigured: !!(accountSid && authToken && fromNumber),
      fromNumber: fromNumber || "",
      defaultToNumber,
      verifiedNumbers,
      autoDetected
    });
  });

  function isPlaceholderNumber(phone: any): boolean {
    if (!phone) return true;
    const clean = String(phone).trim().toLowerCase();
    return (
      clean === "" ||
      clean.includes("xxxx") ||
      clean.includes("abc") ||
      clean.includes("12345") ||
      clean.length < 7
    );
  }

  // API to send real SMS via Twilio using lazy credentials initialization
  app.post("/api/send-sms", async (req, res) => {
    let { to, body } = req.body;
    
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const fromNumber = process.env.TWILIO_PHONE_NUMBER;

    if (!accountSid || !authToken || !fromNumber) {
      return res.status(400).json({
        error: "SMS configuration is missing.",
        details: "Twilio credentials (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN) are not configured in your Secrets settings. Please add them to enable actual SMS notifications."
      });
    }

    // Fall back to environment variable if no 'to' is supplied or if it's empty or a placeholder
    if (!to || isPlaceholderNumber(to)) {
      to = process.env.TWILIO_TO_PHONE_NUMBER || "";
    }

    // If still empty or a placeholder, automatically query Twilio outgoing caller IDs to find their registered phone number
    if (!to || isPlaceholderNumber(to)) {
      try {
        const client = twilio(accountSid, authToken);
        const callerIds = await client.outgoingCallerIds.list({ limit: 5 });
        if (callerIds && callerIds.length > 0 && callerIds[0].phoneNumber) {
          to = callerIds[0].phoneNumber;
          console.log(`[Twilio Engine] Autorouted alert to primary registered caller ID: ${to}`);
        }
      } catch (err: any) {
        console.error("Failed to auto-detect verified trial caller ID:", err);
      }
    }

    if (!to || String(to).trim() === "") {
      return res.status(400).json({
        error: "Missing target phone number",
        details: "We couldn't detect any valid phone number to send actual alerts to. Please either enter your personal phone number in the web dashboard, configure the 'TWILIO_TO_PHONE_NUMBER' inside Secrets, or make sure your personal phone number is registered as a verified Caller ID in your Twilio console."
      });
    }

    // Check if user is attempting to send message *from* and *to* the same number
    const cleanTo = String(to).replace(/\s+/g, '');
    const cleanFrom = String(fromNumber).replace(/\s+/g, '');
    if (cleanTo === cleanFrom) {
      return res.status(400).json({
        error: "Self-messaging restriction",
        details: `Your target phone number (${to}) and Twilio sender number (${fromNumber}) are identical. Twilio trial accounts cannot send messages to their own sender CLI number. Please type your primary personal mobile number inside the console to receive the alerts.`
      });
    }

    try {
      const client = twilio(accountSid, authToken);
      const message = await client.messages.create({
        body,
        from: fromNumber,
        to
      });
      res.json({ success: true, sid: message.sid, sentTo: to });
    } catch (error: any) {
      console.error("Twilio SMS send failed:", error);
      
      let errorDetails = error.message || String(error);
      const errCode = error.code;
      
      if (errCode === 21266 || errorDetails.includes("cannot be the same")) {
        errorDetails = `Configuration mismatch: The target phone number ('To') and the Twilio sender number ('From') are identical (${fromNumber}). Please make sure to enter your own personal mobile phone number in the web interface, and configure your official Twilio Phone Number inside the Google AI Studio Secrets manager (not your personal phone number).`;
      } else if (errCode === 21659 || errorDetails.includes("is not a Twilio phone number") || errorDetails.includes("not a valid Phone Number")) {
        errorDetails = `Invalid Twilio Sender: The number '${fromNumber}' is not a registered Twilio phone number. Please open the Google AI Studio settings and verify that your TWILIO_PHONE_NUMBER secret matches your purchased/verified Twilio trial phone number starting with '+' (e.g. +1855XXXXXXX). Don't set this to your personal phone number!`;
      } else if (errCode === 21608 || errorDetails.includes("is not verified")) {
        errorDetails = `Unverified Sender/Recipient: The number '${to}' is in a Twilio Trial account but hasn't been verified yet. On Twilio free/trial plans, you can ONLY send messages to your own personal phone number which was verified during signup. Go to Twilio Console -> Verified Caller IDs to register this number first!`;
      }

      res.status(500).json({
        error: "Failed to send SMS via Twilio Service.",
        details: errorDetails
      });
    }
  });

  // Serve static assets or mount Vite dev server middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
