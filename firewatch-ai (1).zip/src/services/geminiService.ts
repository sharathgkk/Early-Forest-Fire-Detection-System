import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getRiskPrediction(sensorData: any[]) {
  try {
    const prompt = `Based on the following sensor data from the last hour: ${JSON.stringify(sensorData)}, predict the forest fire risk percentage (0-100%) and identify key risk factors. Return the results in JSON format with keys: riskPercentage (number), factors (array of strings), and a short summary (string).`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskPercentage: { type: Type.NUMBER },
            factors: { type: Type.ARRAY, items: { type: Type.STRING } },
            summary: { type: Type.STRING }
          },
          required: ["riskPercentage", "factors", "summary"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return null;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
}
