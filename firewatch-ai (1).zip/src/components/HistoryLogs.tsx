import React from 'react';
import { motion } from 'motion/react';
import { FileText, Download, Calendar, Map, Activity, ExternalLink } from 'lucide-react';

const MOCK_LOGS = [
  { id: 'LOG-8821', date: '2026-04-25', zone: 'Zone 2', type: 'Wildfire', severity: 'High', area: '12.4 ha', status: 'Contained' },
  { id: 'LOG-8819', date: '2026-04-20', zone: 'Zone 4', type: 'Spot Fire', severity: 'Low', area: '0.2 ha', status: 'Suppressed' },
  { id: 'LOG-8792', date: '2026-04-12', zone: 'Zone 1', type: 'Controlled Burn', severity: 'None', area: '5.0 ha', status: 'Completed' },
  { id: 'LOG-8755', date: '2026-03-29', zone: 'Zone 3', type: 'Smoke Detection', severity: 'Medium', area: '--', status: 'False Alarm' },
  { id: 'LOG-8742', date: '2026-03-22', zone: 'Zone 2', type: 'Wildfire', severity: 'Critical', area: '84.1 ha', status: 'Extinguished' },
];

export default function HistoryLogs() {
  return (
    <div className="p-8 h-full flex flex-col gap-8 max-w-6xl mx-auto w-full transition-colors duration-300">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight uppercase">History & Analysis</h1>
          <p className="text-[var(--text-secondary)] text-sm mt-1">Archive of past incidents and automated reports</p>
        </div>
        
        <button className="px-6 py-2.5 bg-[var(--text-primary)] text-[var(--bg-primary)] text-xs font-bold uppercase tracking-widest rounded-lg flex items-center gap-2 hover:brightness-110 transition-colors">
          <Download size={16} />
          Export All Records
        </button>
      </div>

      <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden flex flex-col transition-colors">
          <div className="flex bg-[var(--bg-tertiary)] border-b border-[var(--border-color)] px-6 py-4">
             <div className="w-[15%] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Report ID</div>
             <div className="w-[15%] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Date</div>
             <div className="w-[15%] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Zone</div>
             <div className="w-[20%] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Incident Type</div>
             <div className="w-[15%] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Severity</div>
             <div className="w-[20%] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Current Status</div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
             {MOCK_LOGS.map((log, i) => (
               <motion.div 
                 key={log.id}
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: 0 }}
                 transition={{ delay: i * 0.05 }}
                 className="flex px-6 py-5 border-b border-[var(--border-color)] hover:bg-[var(--text-primary)]/[0.02] transition-colors group"
               >
                  <div className="w-[15%] font-mono text-sm text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">{log.id}</div>
                  <div className="w-[15%] text-sm text-[var(--text-secondary)]">{log.date}</div>
                  <div className="w-[15%] text-sm text-[var(--text-secondary)] font-bold uppercase">{log.zone}</div>
                  <div className="w-[20%] text-sm text-[var(--text-primary)] font-medium">{log.type}</div>
                  <div className="w-[15%]">
                     <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                        log.severity === 'Critical' ? 'bg-red-600 text-white' : 
                        log.severity === 'High' ? 'bg-red-500/10 text-red-500' :
                        log.severity === 'Medium' ? 'bg-orange-500/10 text-orange-500' : 'bg-green-500/10 text-green-500'
                     }`}>
                        {log.severity}
                     </span>
                  </div>
                  <div className="w-[20%] flex items-center justify-between">
                     <span className="text-sm font-medium text-[var(--text-primary)]/80">{log.status}</span>
                     <button className="p-2 bg-[var(--bg-tertiary)] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                        <ExternalLink size={14} className="text-[var(--text-secondary)]" />
                     </button>
                  </div>
               </motion.div>
             ))}
          </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
         <div className="p-8 bg-gradient-to-br from-indigo-500/5 to-transparent border border-[var(--border-color)] rounded-3xl transition-colors">
            <Activity className="text-indigo-400 mb-4" size={32} />
            <h3 className="text-xl font-bold text-[var(--text-primary)] uppercase tracking-tight mb-2">Annual Trend Analysis</h3>
            <p className="text-sm text-[var(--text-secondary)] leading-relaxed mb-6">
              Long-term data shows a 14% increase in humidity levels across Zone 1 compared to the same period in 2025, possibly due to higher-than-average spring precipitation.
            </p>
            <button className="text-indigo-400 text-xs font-bold uppercase tracking-widest hover:underline">Download Detailed Report</button>
         </div>
         <div className="p-8 bg-gradient-to-br from-orange-500/5 to-transparent border border-[var(--border-color)] rounded-3xl transition-colors">
            <Calendar className="text-orange-400 mb-4" size={32} />
            <h3 className="text-xl font-bold text-[var(--text-primary)] uppercase tracking-tight mb-2">Upcoming Inspection Sched.</h3>
            <p className="text-sm text-[var(--text-secondary)] leading-relaxed mb-6">
              Ground sensor nodes in Sector 42 (Zone 4) are scheduled for hardware maintenance on May 15th. Drones will perform automated calibration flights.
            </p>
            <button className="text-orange-400 text-xs font-bold uppercase tracking-widest hover:underline">Manage Schedule</button>
         </div>
      </div>
    </div>
  );
}
