/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Rss, 
  AlertTriangle, 
  Zap, 
  History, 
  Bell,
  Menu,
  X,
  Thermometer,
  Droplets,
  Wind,
  Flame,
  ChevronRight,
  ShieldAlert,
  CircleStop,
  Wifi,
  LogOut,
  User as UserIcon,
  Cpu,
  Sun,
  Moon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './lib/firebase';
import { ViewType, SensorData, FireAlert, NavItem, IncidentStatus, SensorNode, Sprinkler, Drone, CameraNode } from './types';
import Dashboard from './components/Dashboard';
import Monitoring from './components/Monitoring';
import Alerts from './components/Alerts';
import Predictions from './components/Predictions';
import HistoryLogs from './components/HistoryLogs';
import Notifications from './components/Notifications';
import FleetManagement from './components/FleetManagement';
import Login from './components/Login';

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'monitoring', label: 'Live Monitoring', icon: Rss },
  { id: 'fleet', label: 'Fleet Status', icon: Cpu },
  { id: 'alerts', label: 'Incidents', icon: AlertTriangle },
  { id: 'predictions', label: 'Risk AI', icon: Zap },
  { id: 'history', label: 'History Logs', icon: History },
  { id: 'notifications', label: 'Notifications', icon: Bell },
];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [sensorHistory, setSensorHistory] = useState<SensorData[]>([]);
  const [incidentStatus, setIncidentStatus] = useState<IncidentStatus>('resolved');
  const [incidentLocation, setIncidentLocation] = useState<{ x: number, y: number } | null>(null);
  
  const [alerts, setAlerts] = useState<FireAlert[]>([]);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('firewatch-theme');
      return (saved as 'dark' | 'light') || 'dark';
    }
    return 'dark';
  });

  // Theme Sync
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
    localStorage.setItem('firewatch-theme', theme);
  }, [theme]);

  const sensors = useMemo(() => {
    const nodes: SensorNode[] = [];
    const actions = [
      "No action needed.",
      "Check signal interference.",
      "Clean lens cover.",
      "Battery swap recommended.",
      "Firmware patch available."
    ];
    
    for (let i = 0; i < 120; i++) {
      const isProblem = i % 25 === 0; // Simulate some problems
      nodes.push({
        id: `S-${i}`,
        x: Math.random() * 800,
        y: Math.random() * 600,
        status: isProblem ? (i % 50 === 0 ? 'offline' : 'maintenance') : 'active',
        battery: Math.floor(Math.random() * 60 + 40),
        health: Math.floor(Math.random() * 30 + 70),
        coverageRadius: 40,
        lastTransmission: new Date().toISOString(),
        recommendedAction: isProblem ? actions[Math.floor(Math.random() * actions.length)] : undefined
      });
    }
    return nodes;
  }, []);

  const drones = useMemo(() => {
    const units: Drone[] = [];
    const droneNames = ["Raptor-1", "Seeker-4", "Eye-Alpha", "Titan-Echo", "Ghost-7"];
    const actions = [
      "Calibrate gyro.",
      "Replace rotor B2.",
      "Software sync required.",
      "Lens cleaning."
    ];

    for (let i = 0; i < 5; i++) {
      const isProblem = i === 3;
      units.push({
        id: `DRN-0${i+1}`,
        name: droneNames[i],
        status: i === 0 ? 'responding' : (isProblem ? 'maintenance' : 'patrolling'),
        battery: Math.floor(Math.random() * 50 + 50),
        location: { x: Math.random() * 800, y: Math.random() * 600 },
        health: isProblem ? 72 : 98,
        lastService: '2026-04-12',
        estimatedRepairTime: isProblem ? "45 mins" : undefined,
        maintenanceDetail: isProblem ? "Thermal sensor calibration error detected in port B. Signal noise exceeds 15% threshold." : undefined,
        recommendedAction: isProblem ? actions[Math.floor(Math.random() * actions.length)] : undefined
      });
    }
    return units;
  }, []);

  const sprinklers = useMemo(() => {
    const nodes: Sprinkler[] = [];
    for (let i = 0; i < 60; i++) {
        nodes.push({
            id: `SPR-${i}`,
            x: Math.random() * 800,
            y: Math.random() * 600,
            isActive: false,
            zone: `Z-${Math.floor(i/15) + 1}`
        });
    }
    return nodes;
  }, []);

  const cameras = useMemo(() => {
    const nodes: CameraNode[] = [];
    const models = ["PTZ-Spectra C1", "Thermal Eye-V2", "MultiScan Panoramic", "Apex NightHawk"];
    for (let i = 0; i < 40; i++) {
      const isProblem = i % 13 === 0;
      nodes.push({
        id: `CAM-${i}`,
        x: Math.random() * 800,
        y: Math.random() * 600,
        status: isProblem ? (i % 26 === 0 ? 'offline' : 'maintenance') : 'active',
        battery: Math.floor(Math.random() * 50 + 50),
        model: models[i % models.length],
        angle: Math.floor(Math.random() * 360),
        zone: `Z-${Math.floor(i/10) + 1}`
      });
    }
    return nodes;
  }, []);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        setAuthLoading(false);
      } else {
        const localUser = localStorage.getItem('firewatch-sandbox-user');
        if (localUser) {
          try {
            setUser(JSON.parse(localUser));
          } catch (_) {
            setUser(null);
          }
        } else {
          setUser(null);
        }
        setAuthLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Simulation Logic: Manual only
  const runSimulation = async () => {
    if (incidentStatus !== 'resolved') return; // Don't trigger if already active

    // 1. Detection
    setIncidentStatus('detecting');
    const loc = { x: 150 + Math.random() * 500, y: 150 + Math.random() * 300 };
    setIncidentLocation(loc);
    
    await new Promise(r => setTimeout(r, 4000));
    
    // 2. Dispatch Drone
    setIncidentStatus('dispatching');
    await new Promise(r => setTimeout(r, 6000));

    // 3. AI Analysis
    setIncidentStatus('analyzing');
    await new Promise(r => setTimeout(r, 5000));

    // 4. Confirm & Alert
    const isReal = Math.random() > 0.3;
    if (isReal) {
      setIncidentStatus('confirmed');
      const newAlert: FireAlert = {
        id: `alert-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        zone: 'Sector 7',
        location: `Coord ${loc.x.toFixed(0)}, ${loc.y.toFixed(0)}`,
        timestamp: Date.now(),
        severity: 'high',
        description: 'AI CONFIRMED: High-intensity thermal bloom detected. Emergency sprinklers armed.',
        resolved: false
      };
      setAlerts(prev => [newAlert, ...prev]);
      
      await new Promise(r => setTimeout(r, 4000));
      
      // 5. Suppress
      setIncidentStatus('suppressing');
      await new Promise(r => setTimeout(r, 10000));
    }

    // 6. Resolved
    setIncidentStatus('resolved');
    setIncidentLocation(null);
  };

  // Existing Sensor Update Logic
  useEffect(() => {
    const interval = setInterval(() => {
      setSensorHistory(prev => {
        const last = prev[prev.length - 1] || {
          temperature: 28,
          humidity: 45,
          smokeLevel: 10,
          windSpeed: 12
        };

        // Increase values during incident
        const factor = incidentStatus !== 'resolved' ? 1.5 : 1;

        const newData: SensorData = {
          timestamp: Date.now(),
          temperature: parseFloat((last.temperature + (Math.random() - 0.5) * 0.5 * factor).toFixed(1)),
          humidity: parseFloat((last.humidity + (Math.random() - 0.5) * 1).toFixed(1)),
          smokeLevel: Math.max(0, last.smokeLevel + (Math.random() - 0.5) * 2 * factor),
          windSpeed: parseFloat(Math.max(0, last.windSpeed + (Math.random() - 0.5) * 1).toFixed(2)),
        };

        return [...prev.slice(-29), newData];
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []); // Run once on mount

  const currentStats = sensorHistory[sensorHistory.length - 1] || null;

  if (authLoading) {
    return (
      <div className="h-screen bg-[#050505] flex items-center justify-center">
        <motion.div 
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="w-12 h-12 bg-orange-600 rounded-xl"
        />
      </div>
    );
  }

  if (!user) {
    return <Login onLoginSuccess={() => {}} />;
  }

  return (
    <div className={`flex h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] font-sans selection:bg-orange-500 selection:text-white overflow-hidden transition-colors duration-300`}>
      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 80 }}
        className="flex flex-col border-r border-[var(--border-color)] bg-[var(--bg-secondary)] relative z-20 transition-colors duration-300"
      >
        <div className="p-6 flex items-center justify-between overflow-hidden">
          {isSidebarOpen && (
            <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               className="flex items-center gap-3"
            >
              <div className="w-8 h-8 bg-orange-600 rounded flex items-center justify-center">
                <Flame className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight">FireWatch <span className="text-orange-500">AI</span></span>
            </motion.div>
          )}
          {!isSidebarOpen && (
             <div className="w-full flex justify-center">
               <Flame className="w-6 h-6 text-orange-500" />
             </div>
          )}
        </div>

        <nav className="flex-1 mt-6 px-3 space-y-2">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                id={`nav-${item.id}`}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all relative ${
                  isActive 
                    ? 'bg-orange-500/10 text-orange-400' 
                    : 'text-[#8E9299] hover:bg-[#151619] hover:text-white'
                }`}
              >
                <div className={`p-1.5 rounded ${isActive ? 'bg-orange-500 text-white' : ''}`}>
                  <Icon className="w-5 h-5" />
                </div>
                {isSidebarOpen && (
                  <span className="font-medium">{item.label}</span>
                )}
                {isActive && (
                  <motion.div 
                    layoutId="active-indicator"
                    className="absolute right-0 w-1 h-6 bg-orange-500 rounded-l" 
                  />
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[var(--border-color)]">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="w-full h-10 flex items-center justify-center rounded-lg bg-[var(--bg-tertiary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header Bar */}
        <header className="h-16 border-b border-[var(--border-color)] bg-[var(--bg-secondary)]/50 backdrop-blur-md flex items-center justify-between px-8 z-10 transition-colors duration-300">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[var(--text-secondary)] uppercase tracking-widest text-[10px] font-bold">System Status: Active</span>
            </div>
            
            <div className="h-4 w-px bg-[var(--border-color)]" />
            
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-orange-500" />
                <span className="text-sm font-mono text-orange-500">{currentStats?.temperature}°C</span>
              </div>
              <div className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-blue-400" />
                <span className="text-sm font-mono text-blue-400">{currentStats?.humidity}%</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
             <button
               onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
               className="p-2 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all"
               title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
             >
               {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
             </button>

             <div className="flex items-center gap-3 px-4 py-1.5 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-full text-xs">
                <div className="flex items-center gap-2 pr-3 border-r border-[var(--border-color)]">
                  <div className="w-5 h-5 rounded-full overflow-hidden border border-[var(--border-color)]">
                    {user?.photoURL ? (
                      <img src={user.photoURL} alt={user.displayName || ''} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <UserIcon size={12} className="m-auto text-[var(--text-secondary)]" />
                    )}
                  </div>
                  <span className="text-[var(--text-secondary)] font-medium">{user?.displayName?.split(' ')[0]}</span>
                </div>
                <button 
                  onClick={() => {
                    localStorage.removeItem('firewatch-sandbox-user');
                    auth.signOut();
                    setUser(null);
                  }}
                  className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] flex items-center gap-1.5 transition-colors"
                  title="Logout"
                >
                  <LogOut size={14} />
                  <span>Exit</span>
                </button>
             </div>
             <div className="flex items-center gap-2 px-3 py-1 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-full text-xs text-[var(--text-secondary)]">
               <Wifi size={14} className="text-green-500" />
               <span>SatLink-04 Connected</span>
             </div>
             <button 
               onClick={() => setActiveView('notifications')}
               className="relative"
             >
               <Bell className="w-5 h-5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors" />
               <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 border-2 border-[var(--bg-secondary)] rounded-full" />
             </button>
          </div>
        </header>

        {/* Emergency Overlay */}
        <AnimatePresence>
          {incidentStatus === 'confirmed' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-x-8 top-20 z-50 pointer-events-none"
            >
              <div className="max-w-xl mx-auto bg-red-600 shadow-[0_0_50px_rgba(220,38,38,0.5)] border border-red-400 rounded-2xl p-6 flex items-center gap-6 text-white overflow-hidden relative">
                 <motion.div 
                   animate={{ opacity: [1, 0.5, 1] }} 
                   transition={{ repeat: Infinity, duration: 1 }}
                   className="absolute inset-0 bg-red-500/20" 
                 />
                 <ShieldAlert size={48} className="relative z-10 animate-pulse" />
                 <div className="relative z-10">
                    <h2 className="text-2xl font-black uppercase tracking-tighter">Emergency Dispatched</h2>
                    <p className="text-sm font-bold text-red-100 uppercase opacity-90">Forest Dept & Local Firefighters Notified · Sprinklers Online</p>
                 </div>
                 <div className="ml-auto relative z-10 bg-white/20 px-4 py-2 rounded-lg font-mono font-bold text-xl">
                   01:34
                 </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* View Content */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {activeView === 'dashboard' && <Dashboard 
                alerts={alerts} 
                currentStats={currentStats} 
                sensors={sensors}
                sprinklers={sprinklers}
                cameras={cameras}
                incidentStatus={incidentStatus}
                incidentLocation={incidentLocation}
              />}
              {activeView === 'monitoring' && <Monitoring 
                sensorHistory={sensorHistory} 
                incidentStatus={incidentStatus}
                incidentLocation={incidentLocation}
                onTriggerSimulation={runSimulation}
                cameras={cameras}
              />}
              {activeView === 'alerts' && <Alerts alerts={alerts} />}
              {activeView === 'predictions' && <Predictions sensorHistory={sensorHistory} />}
              {activeView === 'fleet' && <FleetManagement sensors={sensors} drones={drones} cameras={cameras} />}
              {activeView === 'history' && <HistoryLogs />}
              {activeView === 'notifications' && <Notifications alerts={alerts} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
