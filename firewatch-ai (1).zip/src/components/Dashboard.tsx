import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import bandipurSatelliteImg from '../assets/images/bandipur_satellite_1779604905471.png';
import { 
  ShieldAlert, 
  Map as MapIcon, 
  Compass, 
  Target, 
  Wind, 
  Droplets, 
  Thermometer, 
  X, 
  Activity, 
  Battery, 
  Wifi, 
  Zap,
  Radio,
  Eye,
  Video
} from 'lucide-react';
import { FireAlert, SensorData, SensorNode, Sprinkler, IncidentStatus, CameraNode } from '../types';

interface DashboardProps {
  alerts: FireAlert[];
  currentStats: SensorData | null;
  sensors: SensorNode[];
  sprinklers: Sprinkler[];
  cameras: CameraNode[];
  incidentStatus: IncidentStatus;
  incidentLocation: { x: number, y: number } | null;
}

export default function Dashboard({ 
    alerts, 
    currentStats, 
    sensors, 
    sprinklers, 
    cameras = [],
    incidentStatus, 
    incidentLocation 
}: DashboardProps) {
  const [selectedItem, setSelectedItem] = useState<{ type: 'sensor' | 'sprinkler' | 'camera', data: any } | null>(null);

  return (
    <div className="p-8 h-full flex flex-col gap-8 transition-colors duration-300">
      {/* Top Banner Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard 
          label="Air Temp" 
          value={`${currentStats?.temperature || '--'}°C`} 
          sub={incidentStatus === 'confirmed' ? "CRITICAL ALERT" : "Normal Perimeter"} 
          icon={Thermometer} 
          color={incidentStatus === 'confirmed' ? "text-red-500 animate-pulse" : "text-orange-500"} 
        />
        <StatsCard 
          label="Humidity" 
          value={`${currentStats?.humidity || '--'}%`} 
          sub="Risk < 20%" 
          icon={Droplets} 
          color="text-blue-400" 
        />
        <StatsCard 
          label="Wind Speed" 
          value={`${currentStats?.windSpeed ? currentStats.windSpeed.toFixed(2) : '--'} km/h`} 
          sub="S-SW Direction" 
          icon={Wind} 
          color="text-emerald-400" 
        />
        <StatsCard 
          label="Mission Status" 
          value={incidentStatus === 'dispatching' ? 'DRONE DISPATCHED' : incidentStatus.toUpperCase()} 
          sub={incidentLocation ? `X:${incidentLocation.x.toFixed(0)} Y:${incidentLocation.y.toFixed(0)}` : "Standby"} 
          icon={ShieldAlert} 
          color={incidentStatus !== 'resolved' ? "text-orange-500" : "text-green-500"} 
        />
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-8 min-h-0">
        {/* Real-time Map with Satellite Image */}
        <div className="lg:col-span-2 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden flex flex-col relative group">
          <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)]">
            <div className="flex items-center gap-2">
              <MapIcon className="w-4 h-4 text-orange-500" />
              <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-secondary)]">Live Satellite Monitoring (Bandipur Forest)</span>
            </div>
            <div className="flex items-center gap-4 text-[10px] font-mono text-[var(--text-muted)]">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full border border-orange-500/50" /> <span>Sensor Node</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-blue-500/40" /> <span>Sprinkler</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-purple-500/40" /> <span>Camera Node</span>
              </div>
            </div>
          </div>
          
          <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden" onClick={() => setSelectedItem(null)}>
             {/* Satellite Forest Image Background */}
             <img 
               src={bandipurSatelliteImg} 
               alt="Bandipur Forest Satellite Map"
               className="absolute inset-0 w-full h-full object-cover opacity-60"
               referrerPolicy="no-referrer"
             />
             
             <svg viewBox="0 0 800 600" className="w-full h-full max-h-[600px] z-10 relative">
                {/* 1. Render Sensor Grid */}
                {sensors.map(sensor => (
                    <g 
                      key={sensor.id} 
                      className="cursor-pointer group/node"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedItem({ type: 'sensor', data: sensor });
                      }}
                    >
                        <circle 
                            cx={sensor.x} 
                            cy={sensor.y} 
                            r={selectedItem?.data?.id === sensor.id ? 30 : 20} 
                            fill={selectedItem?.data?.id === sensor.id ? "rgba(249, 115, 22, 0.1)" : "transparent"} 
                            stroke={selectedItem?.data?.id === sensor.id ? "rgba(249, 115, 22, 0.6)" : "rgba(249, 115, 22, 0.2)"} 
                            strokeWidth="2"
                        />
                        <circle 
                          cx={sensor.x} 
                          cy={sensor.y} 
                          r={selectedItem?.data?.id === sensor.id ? 8 : 5} 
                          fill="#f97316" 
                          className={selectedItem?.data?.id === sensor.id ? "opacity-100 shadow-[0_0_15px_#f97316]" : "opacity-70 group-hover/node:opacity-100"} 
                        />
                    </g>
                ))}

                {/* 2. Render Sprinklers */}
                {sprinklers.map(spr => (
                    <rect 
                        key={spr.id} 
                        x={selectedItem?.data?.id === spr.id ? spr.x - 5 : spr.x - 4} 
                        y={selectedItem?.data?.id === spr.id ? spr.y - 5 : spr.y - 4} 
                        width={selectedItem?.data?.id === spr.id ? 10 : 8} 
                        height={selectedItem?.data?.id === spr.id ? 10 : 8} 
                        fill={selectedItem?.data?.id === spr.id ? '#60a5fa' : (incidentStatus === 'suppressing' ? '#60a5fa' : '#3b82f6')} 
                        className={`cursor-pointer transition-all ${selectedItem?.data?.id === spr.id ? 'opacity-100' : 'opacity-40 hover:opacity-100'}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedItem({ type: 'sprinkler', data: spr });
                        }}
                    />
                ))}

                {/* 2.5. Render Cameras */}
                {cameras.map(cam => {
                  const isSelected = selectedItem?.data?.id === cam.id;
                  return (
                    <g 
                      key={cam.id} 
                      className="cursor-pointer group/node"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedItem({ type: 'camera', data: cam });
                      }}
                    >
                      {/* FOV sweeping cone path */}
                      <path 
                        d={`M ${cam.x} ${cam.y} L ${cam.x + 35 * Math.cos((cam.angle - 30) * Math.PI / 180)} ${cam.y + 35 * Math.sin((cam.angle - 30) * Math.PI / 180)} A 35 35 0 0 1 ${cam.x + 35 * Math.cos((cam.angle + 30) * Math.PI / 180)} ${cam.y + 35 * Math.sin((cam.angle + 30) * Math.PI / 180)} Z`}
                        fill={isSelected ? "rgba(168, 85, 247, 0.25)" : "rgba(168, 85, 247, 0.08)"}
                        stroke={isSelected ? "rgba(168, 85, 247, 0.5)" : "rgba(168, 85, 247, 0.15)"}
                        strokeWidth="1"
                        className={isSelected ? "" : "animate-[pulse_4s_infinite]"}
                      />
                      {/* Camera casing outline */}
                      <circle 
                        cx={cam.x} 
                        cy={cam.y} 
                        r={isSelected ? 11 : 7} 
                        fill={isSelected ? "rgba(168, 85, 247, 0.2)" : "transparent"} 
                        stroke={isSelected ? "rgba(168, 85, 247, 0.7)" : "rgba(168, 85, 247, 0.3)"} 
                        strokeWidth="1.5"
                      />
                      {/* Active green/red camera dot */}
                      <circle 
                        cx={cam.x} 
                        cy={cam.y} 
                        r={isSelected ? 4.5 : 3} 
                        fill={cam.status === 'offline' ? '#ef4444' : cam.status === 'maintenance' ? '#f59e0b' : '#a855f7'} 
                        className={isSelected ? "opacity-100 shadow-[0_0_15px_#a855f7]" : "opacity-80 group-hover/node:opacity-100"} 
                      />
                    </g>
                  );
                })}

                {/* 3. Render Simulated Incident (if active) */}
                {incidentLocation && (
                  <g>
                    {/* Anomaly Highlight */}
                    <motion.circle 
                        initial={{ r: 0 }}
                        animate={{ r: [30, 60, 45] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                        cx={incidentLocation.x} 
                        cy={incidentLocation.y} 
                        fill={incidentStatus === 'confirmed' ? "rgba(239, 68, 68, 0.4)" : "rgba(249, 115, 22, 0.3)"}
                        className="blur-2xl"
                    />
                  </g>
                )}
             </svg>

             {/* UI Overlay on Map */}
             <div className="absolute top-8 left-8 flex flex-col gap-2 pointer-events-none">
                <div className="px-3 py-2 bg-black/80 backdrop-blur rounded border border-white/10 flex items-center gap-3">
                   <Target className="w-4 h-4 text-orange-500" />
                   <div>
                      <div className="text-[10px] text-[#8E9299] uppercase font-bold tracking-tighter">Current GridFocus</div>
                      <div className="text-xs font-mono text-white">42.8712 N, 74.2211 W</div>
                   </div>
                </div>
                <div className="px-3 py-2 bg-black/80 backdrop-blur rounded border border-white/10 flex items-center gap-3">
                   <Radio className="w-4 h-4 text-blue-400" />
                   <div>
                      <div className="text-[10px] text-[#8E9299] uppercase font-bold tracking-tighter">Satellite Scan</div>
                      <div className="text-xs font-mono text-white">Orbiter V5 - ACTIVE</div>
                   </div>
                </div>
             </div>

             <div className="absolute bottom-8 right-8 z-20">
               <div className="flex bg-black/80 backdrop-blur border border-white/10 rounded overflow-hidden shadow-2xl">
                 <button className="p-2 border-r border-white/10 hover:bg-[#111] transition-colors text-xs font-mono text-white">2D</button>
                 <button className="p-2 border-r border-white/10 hover:bg-[#111] transition-colors text-xs font-mono text-orange-500">SATELLITE</button>
                 <button className="p-2 hover:bg-[#111] transition-colors text-xs font-mono text-white">INFRARED</button>
               </div>
             </div>
          </div>
        </div>

        {/* Feed / Alerts Mini Panel */}
        <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl flex flex-col overflow-hidden relative">
          <AnimatePresence mode="wait">
            {selectedItem ? (
              <motion.div 
                key="details"
                initial={{ x: 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 50, opacity: 0 }}
                className="flex flex-col h-full"
              >
                <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)]">
                  <span className={`text-xs font-bold uppercase tracking-widest ${
                    selectedItem.type === 'sensor' ? 'text-orange-500' :
                    selectedItem.type === 'sprinkler' ? 'text-blue-500' : 'text-purple-500'
                  }`}>
                    Node Details: {selectedItem.data.id}
                  </span>
                  <button 
                    onClick={() => setSelectedItem(null)}
                    className="p-1.5 hover:bg-[var(--text-primary)]/10 rounded-lg transition-colors text-[var(--text-secondary)]"
                  >
                    <X size={16} />
                  </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {/* Status Indicator */}
                  <div className="flex items-center gap-4 bg-[var(--bg-tertiary)] p-4 rounded-xl border border-[var(--border-color)]">
                    <div className={`w-3 h-3 rounded-full animate-pulse ${
                      selectedItem.type === 'sensor' ? 'bg-orange-500' :
                      selectedItem.type === 'sprinkler' ? 'bg-blue-500' : 'bg-purple-500'
                    }`} />
                    <div>
                      <div className="text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-widest">Connection Status</div>
                      <div className="text-sm font-bold text-[var(--text-primary)]">
                        {selectedItem.data.status === 'offline' ? 'OFFLINE' : 'REAL-TIME LINK ACTIVE'}
                      </div>
                    </div>
                  </div>

                  {/* Telemetry Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    <DetailBox label="Type" value={selectedItem.type.toUpperCase()} icon={Activity} />
                    <DetailBox label="Signal" value={selectedItem.data.status === 'offline' ? '0%' : `${Math.floor(Math.random() * 10 + 90)}%`} icon={Wifi} />
                    <DetailBox 
                      label={selectedItem.type === 'sensor' || selectedItem.type === 'camera' ? "Battery" : "Pressure"} 
                      value={selectedItem.type === 'sensor' ? "94%" : selectedItem.type === 'camera' ? `${selectedItem.data.battery}%` : "120 PSI"} 
                      icon={selectedItem.type === 'sensor' || selectedItem.type === 'camera' ? Battery : Zap} 
                    />
                    <DetailBox 
                      label={selectedItem.type === 'sensor' ? "Humidity" : selectedItem.type === 'camera' ? "Lens Status" : "Current Flow"} 
                      value={selectedItem.type === 'sensor' ? "18%" : selectedItem.type === 'camera' ? "CLEAN" : "0.0 L/s"} 
                      icon={selectedItem.type === 'sensor' ? Droplets : selectedItem.type === 'camera' ? Eye : Droplets} 
                    />
                  </div>

                  <div className="space-y-3">
                    <h5 className="text-[10px] uppercase font-black text-[#444] tracking-[0.2em]">Hardware Trace</h5>
                    <div className="bg-[#0D0D0D] p-3 rounded-lg border border-white/5 font-mono text-[10px] text-[#555] space-y-1">
                      <div>UID: FW-{selectedItem.data.id}-098X</div>
                      <div>MODEL: {selectedItem.type === 'camera' ? selectedItem.data.model : 'FW-v2-STABLE'}</div>
                      {selectedItem.type === 'camera' && <div>FOV ANGLE: {selectedItem.data.angle}° SWEEP</div>}
                      <div>LOC: {selectedItem.data.x.toFixed(2)}, {selectedItem.data.y.toFixed(2)}</div>
                      <div>ZONE: {selectedItem.data.zone || 'Z-1'}</div>
                    </div>
                  </div>

                  {selectedItem.type === 'sensor' && (
                    <div className="p-4 bg-orange-500/5 border border-orange-500/10 rounded-xl">
                      <div className="text-[10px] text-orange-500 font-bold uppercase mb-2">Internal Diagnostics</div>
                      <p className="text-xs text-[#8E9299] leading-relaxed">
                        Sensor calibrated 4h ago. IR spectrum shows typical foliage temperature of 24°C. No local CO2 spike detected.
                      </p>
                    </div>
                  )}

                  {selectedItem.type === 'camera' && (
                    <div className="p-4 bg-purple-500/5 border border-purple-500/10 rounded-xl">
                      <div className="text-[10px] text-purple-400 font-bold uppercase mb-2">Live Camera Diagnostics</div>
                      <p className="text-xs text-[#8E9299] leading-relaxed">
                        Continuous panoramic sweep active. Lens heaters configured to automatic. Optical zoom status verified at 1.0x baseline. No obstruction or dirt detected on dome enclosure.
                      </p>
                    </div>
                  )}
                </div>

                <div className="p-4 bg-[#0F0F0F] border-t border-[#141414]">
                  <button 
                    className={`w-full py-2 ${
                      selectedItem.type === 'sensor' ? 'bg-orange-600' : 
                      selectedItem.type === 'sprinkler' ? 'bg-blue-600' : 'bg-purple-600'
                    } text-white text-xs font-bold uppercase tracking-widest rounded-lg hover:brightness-110 transition-all`}
                  >
                    Remote Diagnostic Run
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="alerts"
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="flex flex-col h-full"
              >
                <div className="p-4 border-b border-[#141414] flex items-center justify-between bg-[#0F0F0F]">
                  <span className="text-xs font-bold uppercase tracking-widest text-[#8E9299]">Recent Incidents</span>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {alerts.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-[#444] text-center p-8">
                         <ShieldAlert size={48} className="mb-4 opacity-10" />
                         <p className="text-sm">No active threats detected in the marked forest perimeter.</p>
                      </div>
                    ) : (
                      alerts.map(alert => (
                        <motion.div 
                          key={alert.id}
                          initial={{ x: 20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          className={`p-4 rounded-xl border ${
                            alert.severity === 'critical' || alert.severity === 'high' 
                            ? 'bg-red-500/5 border-red-500/20' 
                            : 'bg-orange-500/5 border-orange-500/20'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                             <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                               alert.severity === 'critical' ? 'bg-red-600 text-white' : 'bg-orange-600/20 text-orange-500'
                             }`}>
                               {alert.severity} Risk
                             </span>
                             <span className="text-[10px] font-mono text-[#555]">
                               {new Date(alert.timestamp).toLocaleTimeString()}
                             </span>
                          </div>
                          <h4 className="text-sm font-bold text-white mb-1 uppercase tracking-tight">{alert.zone} · {alert.location}</h4>
                          <p className="text-xs text-[#8E9299] leading-relaxed line-clamp-2">{alert.description}</p>
                        </motion.div>
                      ))
                    )}
                </div>
                <div className="p-4 bg-[#0F0F0F] border-t border-[#141414]">
                   <button className="w-full py-2 bg-[#151619] hover:bg-[#222] text-[#8E9299] text-xs font-bold uppercase tracking-widest rounded-lg transition-colors">
                     View Full Alert Log
                   </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

function DetailBox({ label, value, icon: Icon }: any) {
  return (
    <div className="bg-[var(--bg-tertiary)] p-3 rounded-xl border border-[var(--border-color)] flex items-center gap-3">
      <div className="p-2 bg-[var(--text-primary)]/5 rounded-lg">
        <Icon size={14} className="text-[var(--text-secondary)]" />
      </div>
      <div>
        <div className="text-[9px] uppercase font-bold text-[var(--text-muted)] tracking-wider mb-0.5">{label}</div>
        <div className="text-xs font-bold text-[var(--text-primary)] font-mono">{value}</div>
      </div>
    </div>
  );
}

function StatsCard({ label, value, sub, icon: Icon, color }: any) {
  return (
    <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] p-5 rounded-2xl flex items-center gap-6 group hover:border-[var(--text-muted)] transition-colors">
      <div className={`p-4 rounded-xl bg-[var(--bg-tertiary)] border border-[var(--border-color)] group-hover:scale-105 transition-transform`}>
        <Icon className={`w-6 h-6 ${color}`} />
      </div>
      <div>
        <div className="text-[10px] uppercase font-bold tracking-widest text-[var(--text-muted)] mb-1">{label}</div>
        <div className="text-2xl font-mono text-[var(--text-primary)] mb-0.5">{value}</div>
        <div className="text-[10px] text-[var(--text-secondary)] font-medium">{sub}</div>
      </div>
    </div>
  );
}

