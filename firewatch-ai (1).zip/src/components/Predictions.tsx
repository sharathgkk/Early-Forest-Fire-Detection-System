import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Zap, 
  BrainCircuit, 
  TrendingUp, 
  Wind, 
  Droplets, 
  Thermometer,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { SensorData } from '../types';
import { getRiskPrediction } from '../services/geminiService';

interface PredictionsProps {
  sensorHistory: SensorData[];
}

export default function Predictions({ sensorHistory }: PredictionsProps) {
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<{
    riskPercentage: number;
    factors: string[];
    summary: string;
  } | null>(null);

  const current = sensorHistory[sensorHistory.length - 1];

  const fetchPrediction = async () => {
    setLoading(true);
    // Take the last 10 points for context
    const context = sensorHistory.slice(-10);
    const result = await getRiskPrediction(context);
    if (result) {
      setPrediction(result);
    } else {
      // Fallback/Mock for UI if API fails
      setPrediction({
        riskPercentage: current?.temperature > 35 ? 75 : 15,
        factors: ["Rising air temperature", "Decreased humidity in south ridge", "Moderate wind gusts"],
        summary: "Current conditions indicate a rising risk profile. High-frequency monitoring of southern zones recommended."
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    if (sensorHistory.length > 5 && !prediction && !loading) {
      fetchPrediction();
    }
  }, [sensorHistory.length, prediction, loading]);

  return (
    <div className="p-8 h-full flex flex-col gap-8 max-w-6xl mx-auto w-full transition-colors duration-300">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight uppercase flex items-center gap-3">
            <Sparkles className="text-orange-500" />
            Fire Risk Forecasting
          </h1>
          <p className="text-[var(--text-secondary)] text-sm mt-1">AI-driven predictive analysis based on global sensor networks</p>
        </div>
        
        <button 
          onClick={fetchPrediction}
          disabled={loading}
          className="px-6 py-2.5 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] flex items-center gap-2 disabled:opacity-50 transition-all"
        >
          {loading ? <RefreshCw className="animate-spin" size={16} /> : <Zap size={16} className="text-orange-500" />}
          Refresh AI Analysis
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Risk Percentage Gauge Card */}
        <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl p-10 flex flex-col items-center justify-center relative overflow-hidden group transition-colors">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 to-red-600" />
          
          <div className="relative mb-8">
            <div className="w-64 h-64 rounded-full border-8 border-[var(--border-color)] flex flex-col items-center justify-center">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                key={prediction?.riskPercentage}
                className="text-7xl font-mono font-bold text-[var(--text-primary)]"
              >
                {prediction?.riskPercentage || '--'}<span className="text-3xl opacity-30">%</span>
              </motion.div>
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--text-muted)] mt-2">Current Risk Index</div>
            </div>
            
            {/* Animated Gauge SVG */}
            <svg className="absolute top-0 left-0 w-64 h-64 -rotate-90">
              <circle 
                cx="128" cy="128" r="120" 
                fill="transparent" 
                stroke="#f97316" 
                strokeWidth="8" 
                strokeDasharray="753" 
                strokeDashoffset={753 - (753 * (prediction?.riskPercentage || 0)) / 100}
                className="transition-all duration-1000 ease-out"
              />
            </svg>
          </div>

          <div className="flex gap-4">
             <div className="px-4 py-2 bg-green-500/5 rounded-full border border-green-500/20 text-green-500 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
               Safe 0-25
             </div>
             <div className="px-4 py-2 bg-orange-500/10 rounded-full border border-orange-500/20 text-orange-500 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
               Elevated 25-60
             </div>
             <div className="px-4 py-2 bg-red-500/5 rounded-full border border-red-500/20 text-red-500 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
               CRITICAL 60+
             </div>
          </div>
        </div>

        {/* AI Summary and Factors */}
        <div className="flex flex-col gap-6">
           <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl p-8 flex-1 transition-colors">
              <div className="flex items-center gap-3 mb-6">
                <BrainCircuit className="text-purple-500" />
                <h3 className="text-lg font-bold text-[var(--text-primary)] uppercase tracking-tight">Intelligence Brief</h3>
              </div>
              
              <div className="space-y-6">
                <div className="p-4 bg-[var(--bg-tertiary)] rounded-xl border border-[var(--border-color)]">
                   <p className="text-sm leading-relaxed text-[var(--text-secondary)] italic">
                     "{prediction?.summary || "Analyzing environmental vectors... please wait."}"
                   </p>
                </div>

                <div>
                   <h4 className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] mb-4">Contributing Risk Factors</h4>
                   <div className="flex flex-wrap gap-2">
                      {prediction?.factors?.map((factor, i) => (
                        <motion.div 
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.1 }}
                          key={i} 
                          className="px-3 py-1.5 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-xs text-[var(--text-secondary)] flex items-center gap-2"
                        >
                           <AlertTriangle size={14} className="text-orange-500" />
                           {factor}
                        </motion.div>
                      ))}
                   </div>
                </div>
              </div>
           </div>

           <div className="bg-orange-500/5 border border-orange-500/20 rounded-2xl p-6 flex items-center gap-4">
              <ShieldCheck className="w-8 h-8 text-orange-500 shrink-0" />
              <div>
                 <h4 className="text-sm font-bold text-[var(--text-primary)] uppercase tracking-tight">Adaptive Monitoring Protocol</h4>
                 <p className="text-xs text-[var(--text-secondary)]">AI has automatically increased sensor polling frequency for South-East sectors based on current trend lines.</p>
              </div>
           </div>
        </div>
      </div>

      {/* Input Data Summary */}
      <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl overflow-hidden mt-auto transition-colors">
         <div className="p-4 border-b border-[var(--border-color)] bg-[var(--bg-tertiary)] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">
           Input Data Feed Vector
         </div>
         <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-[var(--border-color)]">
            <div className="p-6 flex flex-col items-center gap-2">
               <Thermometer size={16} className="text-[var(--text-muted)]" />
               <span className="text-sm font-mono text-[var(--text-primary)]">{current?.temperature}°C</span>
               <span className="text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tighter">Surface Temp</span>
            </div>
            <div className="p-6 flex flex-col items-center gap-2">
               <Droplets size={16} className="text-[var(--text-muted)]" />
               <span className="text-sm font-mono text-[var(--text-primary)]">{current?.humidity}%</span>
               <span className="text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tighter">Humid. Profile</span>
            </div>
            <div className="p-6 flex flex-col items-center gap-2">
               <Wind size={16} className="text-[var(--text-muted)]" />
               <span className="text-sm font-mono text-[var(--text-primary)]">{current?.windSpeed?.toFixed(2) || '--'} km/h</span>
               <span className="text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tighter">Velocity Avg</span>
            </div>
            <div className="p-6 flex flex-col items-center gap-2">
               <TrendingUp size={16} className="text-[var(--text-muted)]" />
               <span className="text-sm font-mono text-[var(--text-primary)]">UPWARD</span>
               <span className="text-[10px] text-[var(--text-muted)] uppercase font-bold tracking-tighter">Risk Trend</span>
            </div>
         </div>
      </div>
    </div>
  );
}
