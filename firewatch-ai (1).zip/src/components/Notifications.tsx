import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, Info, ShieldAlert, Cpu, Radio, Zap, X, ChevronRight, CheckCircle2, Clock, MapPin } from 'lucide-react';
import { FireAlert } from '../types';

interface NotificationsProps {
  alerts: FireAlert[];
}

const STATIC_NOTIFICATIONS = [
  { 
    id: 'sys-2', 
    type: 'system', 
    title: 'System Update', 
    time: '1h ago', 
    desc: 'Satellite AI model upgraded to v4.2. Improved pixel-level smoke detection capabilities.', 
    icon: Cpu, 
    color: 'text-blue-400', 
    bg: 'bg-blue-400/5',
    steps: [
      { time: '10:15:00', label: 'Pre-flight Check', desc: 'Dependency verification for kernel upgrade', status: 'completed' },
      { time: '10:20:00', label: 'Deployment', desc: 'Rolling update applied to edge nodes', status: 'completed' },
      { time: '10:30:00', label: 'Inference Test', desc: 'Validation against historical smoke signatures', status: 'completed' },
    ]
  },
  { id: 'sys-3', type: 'info', title: 'Sensor Maintenance', time: '4h ago', desc: 'Node 12 in the North Corridor is currently offline for routine calibration.', icon: Info, color: 'text-indigo-400', bg: 'bg-indigo-400/5' },
  { id: 'sys-4', type: 'prediction', title: 'New Risk Forecast', time: '6h ago', desc: 'AI has generated a new risk map for the coming 48 hours. Review in Risk AI tab.', icon: Zap, color: 'text-orange-500', bg: 'bg-orange-500/5' },
  { id: 'sys-5', type: 'network', title: 'Comms Stabilized', time: 'Yesterday', desc: 'Satellite link backup established. Latency reduced to < 200ms.', icon: Radio, color: 'text-emerald-400', bg: 'bg-emerald-400/5' },
];

export default function Notifications({ alerts }: NotificationsProps) {
  const [selectedNotif, setSelectedNotif] = useState<any | null>(null);

  const allNotifications = useMemo(() => {
    const alertNotifications = alerts.map(alert => ({
      id: alert.id,
      type: 'alert',
      title: `Critical Incident: ${alert.zone}`,
      time: new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      desc: `Confirmed incident at ${alert.location}. Thermal anomaly detected and validated by Risk AI.`,
      icon: ShieldAlert,
      color: 'text-red-500',
      bg: 'bg-red-500/5',
      steps: [
        { time: 'T-00:00', label: 'Detection', desc: `Thermal spike detected at ${alert.location}`, status: 'completed' },
        { time: 'T+00:15', label: 'Validation', desc: 'Risk AI cross-referenced satellite telemetry', status: 'completed' },
        { time: 'T+00:45', label: 'Action', desc: 'Drone fleet dispatched for ground investigation', status: 'completed' },
        { time: 'Ongoing', label: 'Suppression', desc: 'Awaiting local unit confirmation', status: 'active' },
      ]
    }));

    return [...alertNotifications, ...STATIC_NOTIFICATIONS];
  }, [alerts]);

  return (
    <div className="p-8 h-full flex flex-col gap-8 max-w-4xl mx-auto w-full relative transition-colors duration-300">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight uppercase">System Updates</h1>
          <p className="text-[var(--text-secondary)] text-sm mt-1">Real-time terminal logs and emergency broadcasts</p>
        </div>
        
        <button className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] hover:text-[var(--text-secondary)] transition-colors font-mono">
          Mark all as read
        </button>
      </div>

      <div className="space-y-4">
         {allNotifications.map((notif, i) => {
           const Icon = notif.icon;
           return (
             <motion.div 
               key={notif.id}
               initial={{ opacity: 0, x: 20 }}
               animate={{ opacity: 1, x: 0 }}
               transition={{ delay: i * 0.05 }}
               className={`p-6 rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] hover:border-[var(--text-muted)] transition-colors flex items-start gap-6 group`}
             >
                <div className={`p-4 rounded-xl ${notif.bg} border border-[var(--text-primary)]/5`}>
                   <Icon className={`w-6 h-6 ${notif.color}`} />
                </div>
                
                <div className="flex-1">
                   <div className="flex items-center justify-between mb-1">
                      <h3 className="text-md font-bold text-[var(--text-primary)] uppercase tracking-tight">{notif.title}</h3>
                      <span className="text-[10px] font-mono text-[var(--text-muted)]">{notif.time}</span>
                   </div>
                   <p className="text-sm text-[var(--text-secondary)] leading-relaxed mb-4">{notif.desc}</p>
                   
                   <div className="flex gap-2">
                      <button 
                        onClick={() => setSelectedNotif(notif)}
                        className="px-4 py-1.5 bg-[var(--bg-tertiary)] rounded-lg text-[10px] font-bold uppercase tracking-widest text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors flex items-center gap-2"
                      >
                        View Details <ChevronRight size={12} />
                      </button>
                      <button className="px-4 py-1.5 bg-transparent border border-[var(--border-color)] rounded-lg text-[10px] font-bold uppercase tracking-widest text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] transition-colors">
                        Dismiss
                      </button>
                   </div>
                </div>

                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2 opacity-0 group-hover:opacity-100 transition-opacity" />
             </motion.div>
           );
         })}
      </div>

      <div className="mt-8 p-6 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-3xl border-dashed flex flex-col items-center justify-center text-[var(--text-muted)]">
         <div className="w-12 h-12 rounded-full bg-[var(--text-primary)]/5 flex items-center justify-center mb-4">
            <Bell size={24} />
         </div>
         <p className="text-sm">End of recent notification log</p>
      </div>

      {/* Details Side Panel / Modal */}
      <AnimatePresence>
        {selectedNotif && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedNotif(null)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: 400, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 400, opacity: 0 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-[var(--bg-secondary)] border-l border-[var(--border-color)] z-[70] flex flex-col shadow-2xl transition-colors"
            >
              <div className="p-6 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-tertiary)]">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${selectedNotif.bg}`}>
                    <selectedNotif.icon size={18} className={selectedNotif.color} />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-[var(--text-primary)] uppercase tracking-tight">{selectedNotif.title}</h2>
                    <p className="text-[10px] text-[var(--text-muted)] font-mono">{selectedNotif.time}</p>
                  </div>
                </div>
                <button onClick={() => setSelectedNotif(null)} className="p-2 hover:bg-[var(--text-primary)]/5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)] transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8">
                <div className="mb-8">
                  <h3 className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-[0.2em] mb-4 opacity-50">Incident Log Summary</h3>
                  <p className="text-md text-[var(--text-primary)] font-medium leading-relaxed">{selectedNotif.desc}</p>
                </div>

                <div className="space-y-6 relative">
                  <h3 className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-[0.2em] mb-4">Operational Timeline</h3>
                  
                  {/* Timeline logic */}
                  <div className="absolute left-[7px] top-10 bottom-4 w-px bg-[var(--border-color)]" />
                  
                  {selectedNotif.steps ? (
                    selectedNotif.steps.map((step: any, idx: number) => (
                      <div key={idx} className="relative pl-8">
                        <div className={`absolute left-0 top-1 w-4 h-4 rounded-full border-2 border-[var(--bg-secondary)] z-10 flex items-center justify-center
                          ${step.status === 'completed' ? 'bg-green-500' : step.status === 'active' ? 'bg-orange-500' : 'bg-[var(--border-color)]'}
                        `}>
                           {step.status === 'completed' && <CheckCircle2 size={10} className="text-white" />}
                           {step.status === 'active' && <Clock size={10} className="text-white animate-spin" />}
                        </div>
                        <div className="flex items-center justify-between mb-1">
                          <span className={`text-[10px] font-black tracking-widest uppercase ${step.status === 'active' ? 'text-orange-500' : 'text-[var(--text-secondary)]'}`}>
                            {step.label}
                          </span>
                          <span className="text-[10px] font-mono text-[var(--text-muted)]">{step.time}</span>
                        </div>
                        <p className="text-xs text-[var(--text-muted)] leading-relaxed">{step.desc}</p>
                      </div>
                    ))
                  ) : (
                    <div className="p-4 bg-[var(--bg-tertiary)] rounded-xl border border-dashed border-[var(--border-color)] text-center">
                       <p className="text-[10px] text-[var(--text-muted)] font-bold uppercase">No detailed technical log for this status update</p>
                    </div>
                  )}
                </div>

                {selectedNotif.type === 'alert' && (
                  <div className="mt-12 p-5 bg-red-500/5 border border-red-500/10 rounded-2xl">
                    <ShieldAlert size={20} className="text-red-500 mb-3" />
                    <h4 className="text-xs font-bold text-[var(--text-primary)] uppercase mb-2">Emergency Protocols</h4>
                    <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                      Protocol 17a (Wildfire Containment) has been triggered. All field units within 5km radius are on high alert.
                    </p>
                  </div>
                )}
              </div>

              <div className="p-6 bg-[var(--bg-tertiary)] border-t border-[var(--border-color)] space-y-3">
                 <button className="w-full py-3 bg-[var(--text-primary)] text-[var(--bg-primary)] text-[10px] font-black uppercase tracking-[0.2em] rounded-xl hover:brightness-110 transition-all">
                   Full Diagnostic Export
                 </button>
                 <button onClick={() => setSelectedNotif(null)} className="w-full py-3 bg-transparent text-[var(--text-muted)] text-[10px] font-black uppercase tracking-[0.2em] hover:text-[var(--text-primary)] transition-all">
                   Close Terminal
                 </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
