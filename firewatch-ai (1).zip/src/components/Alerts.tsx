import React from 'react';
import { motion } from 'motion/react';
import { 
  ShieldAlert, 
  Clock, 
  MapPin, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle,
  Loader2,
  Filter,
  Search
} from 'lucide-react';
import { FireAlert } from '../types';

interface AlertsProps {
  alerts: FireAlert[];
}

export default function Alerts({ alerts }: AlertsProps) {
  return (
    <div className="p-8 h-full flex flex-col gap-8 max-w-5xl mx-auto w-full transition-colors duration-300">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight uppercase">Incident Center</h1>
          <p className="text-[var(--text-secondary)] text-sm mt-1">Manage active threats and deployment logs</p>
        </div>
        
        <div className="flex gap-4">
           <div className="flex border border-[var(--border-color)] bg-[var(--bg-secondary)] rounded-lg overflow-hidden">
              <div className="px-3 flex items-center border-r border-[var(--border-color)]">
                <Search size={16} className="text-[var(--text-muted)]" />
              </div>
              <input 
                type="text" 
                placeholder="Search incidents..." 
                className="bg-transparent px-4 py-2 text-sm outline-none focus:bg-[var(--bg-tertiary)] transition-colors text-[var(--text-primary)]"
              />
           </div>
           <button className="px-4 py-2 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-lg text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] flex items-center gap-2">
             <Filter size={16} />
             Filter
           </button>
        </div>
      </div>

      {/* Incident List */}
      <div className="space-y-4">
        {alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 border border-dashed border-[var(--border-color)] rounded-3xl text-[var(--text-muted)]">
             <CheckCircle2 size={64} className="mb-4 opacity-10" />
             <p className="text-lg font-medium">No active incidents found</p>
             <p className="text-sm">All zones are currently within safe operational parameters</p>
          </div>
        ) : (
          alerts.map(alert => (
            <motion.div 
              key={alert.id}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className={`group bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden hover:border-[var(--text-muted)] transition-all cursor-pointer`}
            >
              <div className="flex items-stretch">
                 <div className={`w-2 ${
                   alert.severity === 'critical' ? 'bg-red-600' : 
                   alert.severity === 'high' ? 'bg-red-500' : 'bg-orange-500'
                 }`} />
                 
                 <div className="flex-1 p-6 flex items-center justify-between">
                    <div className="flex items-start gap-6">
                       <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                          alert.severity === 'critical' ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-orange-500/10 text-orange-500 border border-orange-500/20'
                       }`}>
                          <ShieldAlert size={28} />
                       </div>
                       
                       <div>
                          <div className="flex items-center gap-2 mb-1">
                             <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-[var(--text-primary)]/5 text-[var(--text-secondary)]">
                                Ref: #{alert.id.padStart(4, '0')}
                             </span>
                             <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded ${
                                alert.severity === 'critical' ? 'bg-red-600 text-white' : 'bg-orange-500/20 text-orange-500'
                             }`}>
                               {alert.severity}
                             </span>
                          </div>
                          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-2 uppercase tracking-wide">{alert.zone} · {alert.location}</h3>
                          <div className="flex items-center gap-4 text-xs text-[var(--text-muted)] font-medium">
                             <div className="flex items-center gap-1.5">
                                <Clock size={14} />
                                {new Date(alert.timestamp).toLocaleString()}
                             </div>
                             <div className="flex items-center gap-1.5">
                                <MapPin size={14} />
                                {alert.location}
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="flex items-center gap-4">
                       <button className="px-6 py-2.5 bg-[var(--text-primary)] text-[var(--bg-primary)] text-xs font-bold uppercase tracking-widest rounded-lg hover:brightness-110 transition-colors">
                         Dispatch Drone
                       </button>
                       <div className="w-10 h-10 rounded-full border border-[var(--border-color)] flex items-center justify-center text-[var(--text-muted)] group-hover:text-[var(--text-primary)] group-hover:bg-[var(--bg-tertiary)] transition-all">
                          <ChevronRight size={20} />
                       </div>
                    </div>
                 </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Stats Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
         <div className="bg-[var(--bg-primary)] border border-[var(--border-color)] p-6 rounded-2xl flex flex-col gap-1 items-center md:items-start transition-colors">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Active Since Launch</span>
            <span className="text-2xl font-mono text-[var(--text-primary)]">428h 12m</span>
         </div>
         <div className="bg-[var(--bg-primary)] border border-[var(--border-color)] p-6 rounded-2xl flex flex-col gap-1 items-center md:items-start transition-colors">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Resolved (24h)</span>
            <span className="text-2xl font-mono text-green-500">12</span>
         </div>
         <div className="bg-[var(--bg-primary)] border border-[var(--border-color)] p-6 rounded-2xl flex flex-col gap-1 items-center md:items-start transition-colors">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Avg Response</span>
            <span className="text-2xl font-mono text-orange-500">4.2m</span>
         </div>
      </div>
    </div>
  );
}
