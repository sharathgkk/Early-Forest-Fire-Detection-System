import { LucideIcon } from 'lucide-react';

export interface SensorNode {
  id: string;
  x: number;
  y: number;
  status: 'active' | 'alert' | 'offline' | 'maintenance';
  battery: number;
  health: number;
  coverageRadius: number;
  lastTransmission: string;
  recommendedAction?: string;
}

export interface Drone {
  id: string;
  name: string;
  status: 'idle' | 'patrolling' | 'responding' | 'charging' | 'maintenance';
  battery: number;
  location: { x: number; y: number };
  health: number;
  lastService: string;
  estimatedRepairTime?: string;
  maintenanceDetail?: string;
  recommendedAction?: string;
}

export interface Sprinkler {
  id: string;
  x: number;
  y: number;
  isActive: boolean;
  zone: string;
}

export interface CameraNode {
  id: string;
  x: number;
  y: number;
  status: 'active' | 'offline' | 'maintenance';
  battery: number;
  model: string;
  angle: number; // sweeping direction index or degree
  zone: string;
}

export type IncidentStatus = 'detecting' | 'dispatching' | 'analyzing' | 'confirmed' | 'suppressing' | 'resolved';

export type ViewType = 'dashboard' | 'monitoring' | 'alerts' | 'predictions' | 'history' | 'notifications' | 'fleet';

export interface SensorData {
  timestamp: number;
  temperature: number;
  humidity: number;
  smokeLevel: number;
  windSpeed: number;
}

export interface FireAlert {
  id: string;
  zone: string;
  location: string;
  timestamp: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  resolved: boolean;
}

export interface RiskPrediction {
  timestamp: number;
  riskPercentage: number;
  factors: string[];
  weatherConditions: {
    temp: number;
    humidity: number;
    wind: string;
  };
}

export interface NavItem {
  id: ViewType;
  label: string;
  icon: LucideIcon;
}
