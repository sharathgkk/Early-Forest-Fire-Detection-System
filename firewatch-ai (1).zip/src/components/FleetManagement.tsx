import React from 'react';
import { motion } from 'motion/react';
import { 
  Cpu, 
  Battery, 
  Wifi, 
  AlertTriangle, 
  CheckCircle2, 
  Wrench, 
  Navigation, 
  Zap,
  Radio,
  Gamepad2,
  Settings2,
  Camera,
  Eye
} from 'lucide-react';
import { SensorNode, Drone, CameraNode } from '../types';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

interface FleetManagementProps {
  sensors: SensorNode[];
  drones: Drone[];
  cameras?: CameraNode[];
}

export default function FleetManagement({ sensors, drones, cameras = [] }: FleetManagementProps) {
  const averageBattery = Math.round(sensors.reduce((acc, s) => acc + s.battery, 0) / sensors.length);
  const cameraIssues = cameras.filter(c => c.status === 'offline' || c.status === 'maintenance').length;
  const issuesFound = sensors.filter(s => s.status === 'offline' || s.status === 'maintenance').length + 
                     drones.filter(d => d.status === 'maintenance').length +
                     cameraIssues;

  return (
    <div className="p-8 h-full flex flex-col gap-8 overflow-y-auto custom-scrollbar transition-colors duration-300">
      {/* Header Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <SummaryCard 
          label="Network Reliability" 
          value="98.4%" 
          sub="Enterprise Link Active" 
          icon={Wifi} 
          color="text-blue-400" 
        />
        <SummaryCard 
          label="Avg Battery" 
          value={`${averageBattery}%`} 
          sub="Grid Balanced" 
          icon={Battery} 
          color="text-green-400" 
        />
        <SummaryCard 
          label="Fleet Capacity" 
          value={`${drones.length}/${drones.length}`} 
          sub="All units responsive" 
          icon={Gamepad2} 
          color="text-orange-400" 
        />
        <SummaryCard 
          label="Active Issues" 
          value={issuesFound.toString()} 
          sub={issuesFound > 0 ? "Maintenance Required" : "All systems green"} 
          icon={AlertTriangle} 
          color={issuesFound > 0 ? "text-red-500" : "text-[var(--text-muted)]"} 
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 flex-1">
        {/* Drone Fleet List */}
        <section className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl overflow-hidden flex flex-col h-[600px]">
          <div className="p-6 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)]">
            <div className="flex items-center gap-3">
              <Navigation className="text-orange-500" size={20} />
              <h2 className="text-lg font-bold tracking-tight text-[var(--text-primary)] uppercase">Aerial Drone Fleet</h2>
            </div>
            <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest bg-[var(--text-primary)]/5 px-2 py-1 rounded">8K LIDAR EQUIPPED</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {drones.map((drone) => (
              <div key={drone.id}>
                <DroneCard drone={drone} />
              </div>
            ))}
          </div>
        </section>

        {/* Sensor High-Priority / Problems List */}
        <section className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl overflow-hidden flex flex-col h-[600px]">
          <div className="p-6 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)]">
            <div className="flex items-center gap-3">
              <Cpu className="text-blue-500" size={20} />
              <h2 className="text-lg font-bold tracking-tight text-[var(--text-primary)] uppercase">Sensor Network Status</h2>
            </div>
            <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest bg-[var(--text-primary)]/5 px-2 py-1 rounded">120 ACTIVE NODES</span>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {/* Filtered for problems or just a sample for the management view */}
            {sensors.slice(0, 15).map((sensor) => (
              <div key={sensor.id}>
                <SensorStatusItem sensor={sensor} />
              </div>
            ))}
            <div className="pt-4 text-center">
              <button className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-[0.2em] hover:text-[var(--text-primary)] transition-colors">
                View All 120 Network Nodes
              </button>
            </div>
          </div>
        </section>

        {/* Camera Sentinel Status List */}
        <section className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl overflow-hidden flex flex-col h-[600px]">
          <div className="p-6 border-b border-[var(--border-color)] flex items-center justify-between bg-[var(--bg-secondary)]">
            <div className="flex items-center gap-3">
              <Camera className="text-purple-500" size={20} />
              <h2 className="text-lg font-bold tracking-tight text-[var(--text-primary)] uppercase">Camera Sentinel Status</h2>
            </div>
            <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest bg-[var(--text-primary)]/5 px-2 py-1 rounded">
              {cameras.length} PERIMETER CAMERAS
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cameras.map((camera) => (
              <div key={camera.id}>
                <CameraStatusItem camera={camera} />
              </div>
            ))}
            {cameras.length === 0 && (
              <div className="h-full flex items-center justify-center p-6 text-center text-[#555] text-xs font-medium uppercase font-mono">
                No Cameras Found
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, sub, icon: Icon, color }: any) {
  return (
    <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] p-6 rounded-3xl relative overflow-hidden group transition-colors">
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
        <Icon size={48} className={color} />
      </div>
      <div className="relative z-10">
        <Icon size={20} className={`${color} mb-4`} />
        <div className="text-2xl font-black text-[var(--text-primary)] mb-0.5 tracking-tight">{value}</div>
        <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-secondary)] mb-1">{label}</div>
        <div className="text-[10px] text-[var(--text-muted)] font-medium">{sub}</div>
      </div>
    </div>
  );
}

function DroneCard({ drone }: { drone: Drone }) {
  const [isRequesting, setIsRequesting] = React.useState(false);
  const [isLogged, setIsLogged] = React.useState(false);

  const handleRequest = async () => {
    const sandboxUserStr = localStorage.getItem('firewatch-sandbox-user');
    let loggedByUid = auth.currentUser?.uid;

    if (sandboxUserStr && !loggedByUid) {
      try {
        const sandboxUser = JSON.parse(sandboxUserStr);
        loggedByUid = sandboxUser.uid;
      } catch (_) {}
    }

    if (!loggedByUid) {
      console.error("User must be signed in to log maintenance tickets.");
      return;
    }

    setIsRequesting(true);

    if (sandboxUserStr || loggedByUid.startsWith('sandbox')) {
      // Offline sandbox simulation flow
      setTimeout(() => {
        setIsLogged(true);
        setIsRequesting(false);
      }, 800);
      return;
    }

    const path = 'maintenance_tickets';
    try {
      await addDoc(collection(db, path), {
        assetId: drone.id,
        assetType: 'drone',
        detail: drone.maintenanceDetail || "No specific detail provided.",
        createdAt: serverTimestamp(),
        status: 'open',
        loggedBy: loggedByUid
      });
      setIsLogged(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } finally {
      setIsRequesting(false);
    }
  };

  return (
    <motion.div 
      whileHover={{ scale: 1.005 }}
      className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] p-6 rounded-2xl flex flex-col gap-6 group transition-colors"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-5">
          <div className={`p-4 rounded-xl ${drone.status === 'responding' ? 'bg-orange-500/10' : 'bg-[var(--text-primary)]/5'}`}>
            <Navigation size={24} className={drone.status === 'responding' ? 'text-orange-500' : 'text-[var(--text-muted)]'} />
          </div>
          <div>
            <h3 className="text-md font-bold text-[var(--text-primary)] mb-1 uppercase tracking-tight">{drone.name}</h3>
            <div className="flex items-center gap-3">
               <div className="flex items-center gap-1.5 text-[10px] text-[var(--text-secondary)] font-bold uppercase tracking-wider">
                 <Battery size={12} className={drone.battery < 20 ? 'text-red-500' : 'text-green-500'} />
                 {drone.battery}%
               </div>
               <div className="flex items-center gap-1.5 text-[10px] text-[var(--text-secondary)] font-bold uppercase tracking-wider">
                 <Radio size={12} />
                 {drone.status.toUpperCase()}
               </div>
            </div>
          </div>
        </div>

        <div className="text-right">
          {drone.health < 90 ? (
            <div className="flex flex-col items-end gap-1">
              <span className="text-[10px] font-bold text-red-500 uppercase tracking-widest flex items-center gap-1">
                <Wrench size={10} /> Maintenance Required
              </span>
              <span className="text-xs font-bold text-[var(--text-primary)] font-mono mt-1">Health: {drone.health}%</span>
            </div>
          ) : (
            <div className="flex flex-col items-end">
               <span className="text-[10px] font-bold text-green-500 uppercase tracking-widest">System Optimal</span>
               <span className="text-[9px] text-[var(--text-muted)]">Health: {drone.health}%</span>
            </div>
          )}
        </div>
      </div>

      {drone.health < 90 && (
        <div className="bg-red-500/5 border border-red-500/10 rounded-xl p-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-[9px] font-black text-red-500/70 uppercase tracking-[0.2em]">Diagnostic Report</div>
              <p className="text-xs text-[var(--text-secondary)] leading-relaxed max-w-md">
                {drone.maintenanceDetail || "Sensor inconsistencies detected during last patrol."}
              </p>
            </div>
            <div className="bg-[var(--bg-primary)] p-2 px-3 rounded-lg border border-[var(--border-color)] text-center">
              <div className="text-[8px] font-bold text-[var(--text-muted)] uppercase mb-0.5">Est. Repair</div>
              <div className="text-xs font-bold text-[var(--text-primary)] font-mono">{drone.estimatedRepairTime || "30 mins"}</div>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-[var(--border-color)] pt-4">
            <div className="flex items-center gap-2">
              <AlertTriangle size={14} className="text-orange-500" />
              <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase">{drone.recommendedAction}</span>
            </div>
            
            {isLogged ? (
              <div className="flex items-center gap-2 text-green-500 bg-green-500/10 px-3 py-1.5 rounded-lg border border-green-500/20">
                <CheckCircle2 size={14} />
                <span className="text-[10px] font-black uppercase tracking-wider">Ticket Logged: #{drone.id}-MT</span>
              </div>
            ) : (
              <button 
                onClick={handleRequest}
                disabled={isRequesting}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isRequesting ? (
                  <>
                    <Zap size={12} className="animate-pulse" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Wrench size={12} />
                    Request Maintenance
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      )}
    </motion.div>
  );
}

function SensorStatusItem({ sensor }: { sensor: SensorNode }) {
  const [isRequesting, setIsRequesting] = React.useState(false);
  const [isLogged, setIsLogged] = React.useState(false);

  const statusColor = sensor.status === 'active' ? 'bg-green-500' : 
                      sensor.status === 'maintenance' ? 'bg-orange-500' : 'bg-red-500';

  const handleRequest = async () => {
    const sandboxUserStr = localStorage.getItem('firewatch-sandbox-user');
    let loggedByUid = auth.currentUser?.uid;

    if (sandboxUserStr && !loggedByUid) {
      try {
        const sandboxUser = JSON.parse(sandboxUserStr);
        loggedByUid = sandboxUser.uid;
      } catch (_) {}
    }

    if (!loggedByUid) {
      console.error("User must be signed in to log maintenance tickets.");
      return;
    }

    setIsRequesting(true);

    if (sandboxUserStr || (loggedByUid && loggedByUid.startsWith('sandbox'))) {
      setTimeout(() => {
        setIsLogged(true);
        setIsRequesting(false);
      }, 800);
      return;
    }

    const path = 'maintenance_tickets';
    try {
      await addDoc(collection(db, path), {
        assetId: sensor.id,
        assetType: 'sensor',
        detail: getSensorDiagnostic(sensor),
        createdAt: serverTimestamp(),
        status: 'open',
        loggedBy: loggedByUid
      });
      setIsLogged(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } finally {
      setIsRequesting(false);
    }
  };

  const getSensorDiagnostic = (s: SensorNode) => {
    if (s.recommendedAction === "Check signal interference.") {
      return "Radio wave interference detected on local ISM 2.4GHz spectrum. Packet collisions exceed 15% threshold causing telemetry delay.";
    }
    if (s.recommendedAction === "Clean lens cover.") {
      return "Optical light index attenuation detected on infrared receptor slot. Airborne soot/fog condensation blocking coverage.";
    }
    if (s.recommendedAction === "Battery swap recommended.") {
      return "Critical battery anode internal resistance increase. Terminal voltage falls below nominal operations line during sweep.";
    }
    if (s.recommendedAction === "Firmware patch available.") {
      return "Out-of-date system firmware. Incompatible with standard telemetry communication layer updates.";
    }
    return "Inconsistent thermal array feedback. Signal noise exceeds 15% threshold in local Sector A receiver.";
  };

  const hasIssue = sensor.status !== 'active';

  return (
    <motion.div 
      whileHover={{ scale: 1.005 }}
      className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] p-5 rounded-2xl flex flex-col gap-4 group transition-colors animate-fade-in"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`w-2.5 h-2.5 rounded-full ${statusColor} shadow-[0_0_8px]`} />
          <div>
            <div className="text-xs font-bold text-[var(--text-primary)] font-mono uppercase tracking-tight">Sensor {sensor.id}</div>
            <div className="flex items-center gap-3 mt-1">
               <span className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider flex items-center gap-1">
                 <Zap size={10} /> {sensor.battery}%
               </span>
               <span className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider flex items-center gap-1">
                 <Settings2 size={10} /> Health: {sensor.health}%
               </span>
            </div>
          </div>
        </div>
        
        {hasIssue ? (
          <div className="text-right">
            <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest flex items-center gap-1 justify-end">
              <Wrench size={10} /> Maintenance Required
            </span>
            <span className="text-[9px] text-[var(--text-muted)]">{sensor.status.toUpperCase()}</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 px-3 py-1 bg-[var(--text-primary)]/5 rounded-lg text-[9px] font-bold text-[var(--text-secondary)]">
            <CheckCircle2 size={10} className="text-green-500" />
            STABLE
          </div>
        )}
      </div>

      {hasIssue && (
        <div className="bg-red-500/5 border border-red-500/10 rounded-xl p-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-[9px] font-black text-red-500/70 uppercase tracking-[0.2em]">Diagnostic Report</div>
              <p className="text-xs text-[var(--text-secondary)] leading-relaxed max-w-md">
                {getSensorDiagnostic(sensor)}
              </p>
            </div>
            <div className="bg-[var(--bg-primary)] p-2 px-3 rounded-lg border border-[var(--border-color)] text-center">
              <div className="text-[8px] font-bold text-[var(--text-muted)] uppercase mb-0.5">Est. Repair</div>
              <div className="text-xs font-bold text-[var(--text-primary)] font-mono">15 mins</div>
            </div>
          </div>

          <div className="pt-2 flex flex-col md:flex-row md:items-center justify-between gap-3 border-t border-[var(--border-color)] pt-4">
            <div className="flex items-center gap-2 font-mono">
              <AlertTriangle size={14} className="text-orange-500" />
              <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase">{sensor.recommendedAction || "Software sync required."}</span>
            </div>
            
            {isLogged ? (
              <div className="flex items-center gap-2 text-green-500 bg-green-500/10 px-3 py-1.5 rounded-lg border border-green-500/20">
                <CheckCircle2 size={14} />
                <span className="text-[10px] font-black uppercase tracking-wider text-xs">Ticket Logged: #{sensor.id}-MT</span>
              </div>
            ) : (
              <button 
                onClick={handleRequest}
                disabled={isRequesting}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isRequesting ? (
                  <>
                    <Zap size={12} className="animate-pulse" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Wrench size={12} />
                    Request Maintenance
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      )}
    </motion.div>
  );
}

function CameraStatusItem({ camera }: { camera: CameraNode }) {
  const [isRequesting, setIsRequesting] = React.useState(false);
  const [isLogged, setIsLogged] = React.useState(false);

  const statusColor = camera.status === 'active' ? 'bg-[#c084fc]' : 
                      camera.status === 'maintenance' ? 'bg-orange-500' : 'bg-red-500';

  const handleRequest = async () => {
    const sandboxUserStr = localStorage.getItem('firewatch-sandbox-user');
    let loggedByUid = auth.currentUser?.uid;

    if (sandboxUserStr && !loggedByUid) {
      try {
        const sandboxUser = JSON.parse(sandboxUserStr);
        loggedByUid = sandboxUser.uid;
      } catch (_) {}
    }

    if (!loggedByUid) {
      console.error("User must be signed in to log maintenance tickets.");
      return;
    }

    setIsRequesting(true);

    if (sandboxUserStr || (loggedByUid && loggedByUid.startsWith('sandbox'))) {
      setTimeout(() => {
        setIsLogged(true);
        setIsRequesting(false);
      }, 800);
      return;
    }

    const path = 'maintenance_tickets';
    try {
      await addDoc(collection(db, path), {
        assetId: camera.id,
        assetType: 'camera',
        detail: getCameraDiagnostic(camera),
        createdAt: serverTimestamp(),
        status: 'open',
        loggedBy: loggedByUid
      });
      setIsLogged(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } finally {
      setIsRequesting(false);
    }
  };

  const getCameraDiagnostic = (c: CameraNode) => {
    if (c.status === 'offline') {
      return "Offline: Camera streaming link interrupted. Network handshake timeout on central perimeter node. Power supply drop detected.";
    }
    return "High optic noise. Thermal lens requires refocusing calibration. Pan-tilt-zoom motor rotation servo torque exceeds limits.";
  };

  const hasIssue = camera.status !== 'active';

  return (
    <motion.div 
      whileHover={{ scale: 1.005 }}
      className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] p-5 rounded-2xl flex flex-col gap-4 group transition-colors animate-fade-in"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`w-2.5 h-2.5 rounded-full ${statusColor} shadow-[0_0_8px]`} />
          <div>
            <div className="text-xs font-bold text-[var(--text-primary)] font-mono uppercase tracking-tight">Cam Sentinel {camera.id}</div>
            <div className="flex items-center gap-3 mt-1">
               <span className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider flex items-center gap-1">
                 <Zap size={10} /> {camera.battery}%
               </span>
               <span className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-wider flex items-center gap-1">
                 <Eye size={10} /> Angle: {camera.angle}°
               </span>
            </div>
          </div>
        </div>
        
        {hasIssue ? (
          <div className="text-right">
            <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest flex items-center gap-1 justify-end">
              <Wrench size={10} /> Action Required
            </span>
            <span className="text-[9px] text-[var(--text-muted)] font-mono">{camera.model} ({camera.status.toUpperCase()})</span>
          </div>
        ) : (
          <div className="flex items-center justify-end gap-2 px-3 py-1 bg-[var(--text-primary)]/5 rounded-lg text-[9px] font-bold text-[var(--text-secondary)]">
            <CheckCircle2 size={10} className="text-purple-400" />
            LIVE SWEEP
          </div>
        )}
      </div>

      {hasIssue && (
        <div className="bg-red-500/5 border border-red-500/10 rounded-xl p-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-[9px] font-black text-red-500/70 uppercase tracking-[0.2em]">Diagnostic Report</div>
              <p className="text-xs text-[var(--text-secondary)] leading-relaxed max-w-md">
                {getCameraDiagnostic(camera)}
              </p>
            </div>
            <div className="bg-[var(--bg-primary)] p-2 px-3 rounded-lg border border-[var(--border-color)] text-center">
              <div className="text-[8px] font-bold text-[var(--text-muted)] uppercase mb-0.5">Est. Repair</div>
              <div className="text-xs font-bold text-[var(--text-primary)] font-mono">45 mins</div>
            </div>
          </div>

          <div className="pt-2 flex flex-col md:flex-row md:items-center justify-between gap-3 border-t border-[var(--border-color)] pt-4">
            <div className="flex items-center gap-2 font-mono">
              <AlertTriangle size={14} className="text-orange-500" />
              <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase">
                {camera.status === 'offline' ? "Check cellular telemetry link" : "Software alignment calibration required"}
              </span>
            </div>
            
            {isLogged ? (
              <div className="flex items-center gap-2 text-green-500 bg-green-500/10 px-3 py-1.5 rounded-lg border border-green-500/20">
                <CheckCircle2 size={14} />
                <span className="text-[10px] font-black uppercase tracking-wider text-xs">Ticket Logged: #{camera.id}-MT</span>
              </div>
            ) : (
              <button 
                onClick={handleRequest}
                disabled={isRequesting}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isRequesting ? (
                  <>
                    <Zap size={12} className="animate-pulse" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Wrench size={12} />
                    Request Maintenance
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      )}
    </motion.div>
  );
}
